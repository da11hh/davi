import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  LogOut, 
  TrendingUp, 
  Users, 
  Target, 
  BarChart3,
  Sparkles,
  Crown,
  Zap,
  Globe,
  ArrowUpRight,
  DollarSign,
  Activity
} from "lucide-react";

const Dashboard = () => {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="min-h-screen bg-luxury relative overflow-hidden">
      {/* Luxury Background Elements */}
      <div className="fixed inset-0 bg-gradient-to-br from-background via-background/98 to-muted/3" />
      
      {/* Premium Ambient Lights */}
      <div className="fixed top-0 left-1/3 w-96 h-96 bg-primary/4 rounded-full blur-3xl animate-float" />
      <div className="fixed bottom-0 right-1/3 w-80 h-80 bg-secondary/3 rounded-full blur-3xl animate-float" style={{ animationDelay: '3s' }} />
      
      {/* Header Executive */}
      <header className="relative z-10 border-b border-border/30 backdrop-blur-xl">
        <div className="container-luxury py-6">
          <div className="flex items-center justify-between">
            {/* Logo Premium */}
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-primary via-primary/90 to-primary/70 rounded-2xl flex items-center justify-center glow-primary">
                  <Sparkles className="w-6 h-6 text-white animate-glow" />
                </div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-gradient-to-br from-secondary to-secondary/80 rounded-full border border-background flex items-center justify-center">
                  <span className="text-xs font-black text-background">AI</span>
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-black gradient-text tracking-tight">ExecutiveAI Pro</h1>
                <p className="text-sm text-muted-foreground/80">Plataforma Executiva</p>
              </div>
            </div>

            {/* User Info & Actions */}
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-semibold text-foreground">{user?.name}</p>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-secondary/10 text-secondary border-secondary/20 font-medium">
                    <Crown className="w-3 h-3 mr-1" />
                    {user?.role}
                  </Badge>
                </div>
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                size="sm"
                className="transition-elegant"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Dashboard Content */}
      <main className="relative z-10 container-luxury py-8 space-y-8 animate-fade-in">
        
        {/* Welcome Section */}
        <div className="space-y-2">
          <h2 className="text-4xl font-black text-foreground tracking-tight">
            Bem-vindo, <span className="gradient-text">{user?.name}</span>
          </h2>
          <p className="text-xl text-muted-foreground/80">
            Sua plataforma executiva está pronta para potencializar seus resultados
          </p>
        </div>

        {/* Executive Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="glass-card border-border/20 hover:shadow-luxury transition-elegant group">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-semibold text-muted-foreground">
                Receita Total
              </CardTitle>
              <DollarSign className="h-4 w-4 text-primary group-hover:text-secondary transition-elegant" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-black gradient-text">R$ 2.4M</div>
              <p className="text-xs text-secondary font-medium flex items-center mt-1">
                <ArrowUpRight className="w-3 h-3 mr-1" />
                +12.5% vs mês anterior
              </p>
            </CardContent>
          </Card>

          <Card className="glass-card border-border/20 hover:shadow-luxury transition-elegant group">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-semibold text-muted-foreground">
                Performance
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-primary group-hover:text-secondary transition-elegant" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-black gradient-text">98.2%</div>
              <p className="text-xs text-secondary font-medium flex items-center mt-1">
                <ArrowUpRight className="w-3 h-3 mr-1" />
                +2.8% eficiência
              </p>
            </CardContent>
          </Card>

          <Card className="glass-card border-border/20 hover:shadow-luxury transition-elegant group">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-semibold text-muted-foreground">
                Equipe Ativa
              </CardTitle>
              <Users className="h-4 w-4 text-primary group-hover:text-secondary transition-elegant" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-black gradient-text">247</div>
              <p className="text-xs text-secondary font-medium flex items-center mt-1">
                <ArrowUpRight className="w-3 h-3 mr-1" />
                +15 novos membros
              </p>
            </CardContent>
          </Card>

          <Card className="glass-card border-border/20 hover:shadow-luxury transition-elegant group">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-semibold text-muted-foreground">
                Metas Atingidas
              </CardTitle>
              <Target className="h-4 w-4 text-primary group-hover:text-secondary transition-elegant" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-black gradient-text">94%</div>
              <p className="text-xs text-secondary font-medium flex items-center mt-1">
                <ArrowUpRight className="w-3 h-3 mr-1" />
                Superando expectativas
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Executive Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Quick Actions */}
          <Card className="glass-card border-border/20 lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Zap className="w-5 h-5 text-primary" />
                <span>Ações Executivas</span>
              </CardTitle>
              <CardDescription>
                Ferramentas premium para otimizar sua liderança
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button variant="glass" className="h-16 justify-start space-x-3">
                  <BarChart3 className="w-5 h-5 text-primary" />
                  <div className="text-left">
                    <p className="font-semibold">Análise Estratégica</p>
                    <p className="text-xs text-muted-foreground">IA para decisões</p>
                  </div>
                </Button>
                
                <Button variant="glass" className="h-16 justify-start space-x-3">
                  <Activity className="w-5 h-5 text-secondary" />
                  <div className="text-left">
                    <p className="font-semibold">Monitor Executivo</p>
                    <p className="text-xs text-muted-foreground">KPIs em tempo real</p>
                  </div>
                </Button>
                
                <Button variant="glass" className="h-16 justify-start space-x-3">
                  <Globe className="w-5 h-5 text-primary" />
                  <div className="text-left">
                    <p className="font-semibold">Mercado Global</p>
                    <p className="text-xs text-muted-foreground">Insights premium</p>
                  </div>
                </Button>
                
                <Button variant="glass" className="h-16 justify-start space-x-3">
                  <Users className="w-5 h-5 text-secondary" />
                  <div className="text-left">
                    <p className="font-semibold">Gestão de Talentos</p>
                    <p className="text-xs text-muted-foreground">IA para RH</p>
                  </div>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Executive Status */}
          <Card className="glass-card border-border/20">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Crown className="w-5 h-5 text-secondary" />
                <span>Status Executivo</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-secondary to-secondary/80 rounded-full mx-auto flex items-center justify-center glow-gold mb-4">
                  <Crown className="w-10 h-10 text-background" />
                </div>
                <h3 className="font-black text-lg gradient-text-gold">Premium Executive</h3>
                <p className="text-sm text-muted-foreground">Acesso total à plataforma</p>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Nível de Acesso</span>
                  <span className="font-semibold text-secondary">CEO</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Sessões IA</span>
                  <span className="font-semibold text-primary">Ilimitadas</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Suporte Premium</span>
                  <span className="font-semibold text-secondary">24/7</span>
                </div>
              </div>

              <Button variant="premium" size="lg" className="w-full">
                <Sparkles className="w-4 h-4 mr-2" />
                Upgrade Premium+
              </Button>
            </CardContent>
          </Card>
        </div>

      </main>
    </div>
  );
};

export default Dashboard;