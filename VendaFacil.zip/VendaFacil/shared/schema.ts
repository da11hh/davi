import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, decimal, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

export const leads = pgTable("leads", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  company: text("company").notNull(),
  companySize: text("company_size").notNull(),
  revenue: text("revenue").notNull(),
  leadsVolume: text("leads_volume").notNull(),
  painPoint: text("pain_point").notNull(),
  timeline: text("timeline").notNull(),
  score: integer("score").notNull(),
  roiData: jsonb("roi_data"),
  status: text("status").default("new").notNull(),
  lgpdConsent: boolean("lgpd_consent").notNull(),
  lgpdConsentDate: timestamp("lgpd_consent_date").notNull(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

export const chatSessions = pgTable("chat_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  leadId: varchar("lead_id").references(() => leads.id),
  messages: jsonb("messages").notNull(),
  status: text("status").default("active").notNull(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

export const demos = pgTable("demos", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  leadId: varchar("lead_id").references(() => leads.id).notNull(),
  scheduledDate: timestamp("scheduled_date").notNull(),
  status: text("status").default("scheduled").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

export const subscriptions = pgTable("subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  plan: text("plan").notNull(),
  status: text("status").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  billingCycle: text("billing_cycle").notNull(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

export const emailTemplates = pgTable("email_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  subject: text("subject").notNull(),
  htmlContent: text("html_content").notNull(),
  textContent: text("text_content").notNull(),
  templateType: text("template_type").notNull(), // welcome, case_study, educational, roi, testimonials, special_offer, last_chance
  delayDays: integer("delay_days").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

export const emailCampaigns = pgTable("email_campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  leadId: varchar("lead_id").references(() => leads.id).notNull(),
  status: text("status").default("active").notNull(), // active, paused, completed, cancelled
  startedAt: timestamp("started_at").default(sql`now()`).notNull(),
  completedAt: timestamp("completed_at"),
  totalEmails: integer("total_emails").default(7).notNull(),
  emailsSent: integer("emails_sent").default(0).notNull(),
  emailsOpened: integer("emails_opened").default(0).notNull(),
  emailsClicked: integer("emails_clicked").default(0).notNull(),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

export const scheduledEmails = pgTable("scheduled_emails", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: varchar("campaign_id").references(() => emailCampaigns.id).notNull(),
  leadId: varchar("lead_id").references(() => leads.id).notNull(),
  templateId: varchar("template_id").references(() => emailTemplates.id).notNull(),
  scheduledAt: timestamp("scheduled_at").notNull(),
  sentAt: timestamp("sent_at"),
  openedAt: timestamp("opened_at"),
  clickedAt: timestamp("clicked_at"),
  status: text("status").default("scheduled").notNull(), // scheduled, sent, opened, clicked, failed
  personalizedSubject: text("personalized_subject").notNull(),
  personalizedContent: text("personalized_content").notNull(),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").default(sql`now()`).notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
});

export const insertLeadSchema = createInsertSchema(leads).pick({
  name: true,
  email: true,
  phone: true,
  company: true,
  companySize: true,
  revenue: true,
  leadsVolume: true,
  painPoint: true,
  timeline: true,
  score: true,
  roiData: true,
  lgpdConsent: true,
  lgpdConsentDate: true,
}).extend({
  // Enhanced email validation using RFC standard
  email: z.string().email("Email deve ter formato válido"),
  // Brazilian phone validation (supports various formats)
  phone: z.string().regex(
    /^(?:\+55\s?)?(?:\(?[1-9]{2}\)?\s?)?(?:9\d{4}[\-\s]?\d{4}|\d{4}[\-\s]?\d{4})$/,
    "Telefone deve ter formato brasileiro válido (ex: (11) 99999-9999)"
  ),
  // Ensure consent is always true (required for LGPD)
  lgpdConsent: z.literal(true, {
    errorMap: () => ({ message: "Consentimento LGPD é obrigatório" })
  })
});

export const insertChatSessionSchema = createInsertSchema(chatSessions).pick({
  leadId: true,
  messages: true,
});

export const insertDemoSchema = createInsertSchema(demos).pick({
  leadId: true,
  scheduledDate: true,
  notes: true,
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).pick({
  userId: true,
  plan: true,
  status: true,
  amount: true,
  billingCycle: true,
});

export const insertEmailTemplateSchema = createInsertSchema(emailTemplates).pick({
  name: true,
  subject: true,
  htmlContent: true,
  textContent: true,
  templateType: true,
  delayDays: true,
  isActive: true,
});

export const insertEmailCampaignSchema = createInsertSchema(emailCampaigns).pick({
  leadId: true,
  status: true,
  totalEmails: true,
});

export const insertScheduledEmailSchema = createInsertSchema(scheduledEmails).pick({
  campaignId: true,
  leadId: true,
  templateId: true,
  scheduledAt: true,
  personalizedSubject: true,
  personalizedContent: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertLead = z.infer<typeof insertLeadSchema>;
export type Lead = typeof leads.$inferSelect;

export type InsertChatSession = z.infer<typeof insertChatSessionSchema>;
export type ChatSession = typeof chatSessions.$inferSelect;

export type InsertDemo = z.infer<typeof insertDemoSchema>;
export type Demo = typeof demos.$inferSelect;

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

export type InsertEmailTemplate = z.infer<typeof insertEmailTemplateSchema>;
export type EmailTemplate = typeof emailTemplates.$inferSelect;

export type InsertEmailCampaign = z.infer<typeof insertEmailCampaignSchema>;
export type EmailCampaign = typeof emailCampaigns.$inferSelect;

export type InsertScheduledEmail = z.infer<typeof insertScheduledEmailSchema>;
export type ScheduledEmail = typeof scheduledEmails.$inferSelect;
