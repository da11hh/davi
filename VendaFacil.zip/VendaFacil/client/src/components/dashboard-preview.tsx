import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface AnalyticsData {
  // Main KPI metrics
  conversas: number;
  agendamentos: number;
  conversaoRate: number;
  receitaGerada: number;
  
  // Growth percentages
  crescimentoConversas: number;
  crescimentoAgendamentos: number;
  crescimentoConversao: number;
  crescimentoReceita: number;
  
  // Legacy compatibility
  totalLeads: number;
  qualifiedLeads: number;
  demos: number;
  conversionRate: number;
  averageScore: number;
  
  // Recent activities
  recentActivities: any[];
  
  // ROI data
  roi: {
    monthlyInvestment: number;
    estimatedRevenue: number;
    roiPercentage: number;
  };
}

export default function DashboardPreview() {
  const { data: analytics, isLoading } = useQuery<AnalyticsData>({
    queryKey: ["/api/analytics"],
  });

  // Loading state
  if (isLoading) {
    return (
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Dashboard de Resultados em Tempo Real</h2>
            <p className="text-xl text-muted-foreground">Carregando métricas...</p>
          </div>
          <div className="bg-card border border-border rounded-2xl p-8 shadow-lg">
            <div className="animate-pulse space-y-4">
              <div className="h-8 bg-muted rounded w-1/3"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[1,2,3,4].map(i => (
                  <div key={i} className="h-24 bg-muted rounded"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  // Helper function to ensure numeric values with robust fallbacks
  const safeNumber = (value: any, fallback: number = 0): number => {
    const num = Number(value);
    return isNaN(num) || num === null || num === undefined ? fallback : num;
  };

  // Use real data with proper fallbacks for type safety
  const data = {
    conversas: safeNumber(analytics?.conversas, 0),
    agendamentos: safeNumber(analytics?.agendamentos, 0),
    conversaoRate: safeNumber(analytics?.conversaoRate, 0),
    receitaGerada: safeNumber(analytics?.receitaGerada, 0),
    crescimentoConversas: safeNumber(analytics?.crescimentoConversas, 0),
    crescimentoAgendamentos: safeNumber(analytics?.crescimentoAgendamentos, 0),
    crescimentoConversao: safeNumber(analytics?.crescimentoConversao, 0),
    crescimentoReceita: safeNumber(analytics?.crescimentoReceita, 0),
    recentActivities: analytics?.recentActivities || [],
    roi: {
      monthlyInvestment: safeNumber(analytics?.roi?.monthlyInvestment, 597),
      estimatedRevenue: safeNumber(analytics?.roi?.estimatedRevenue, 0),
      roiPercentage: safeNumber(analytics?.roi?.roiPercentage, 0)
    }
  };

  return (
    <section className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4" data-testid="dashboard-title">Dashboard de Resultados em Tempo Real</h2>
          <p className="text-xl text-muted-foreground">Acompanhe métricas, conversões e ROI da sua automação</p>
        </div>
        
        <div className="bg-card border border-border rounded-2xl p-8 shadow-lg">
          {/* Dashboard Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="text-2xl font-bold">Visão Geral - {new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</h3>
              <p className="text-muted-foreground">{data.conversas > 0 ? 'Dados em Tempo Real' : 'Aguardando primeiros dados'}</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">7 dias</Button>
              <Button size="sm">30 dias</Button>
              <Button variant="outline" size="sm">90 dias</Button>
            </div>
          </div>
          
          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card data-testid="kpi-conversas">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Conversas Atendidas</CardTitle>
                <i className="fas fa-comments text-primary"></i>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{data.conversas.toLocaleString()}</div>
                <p className="text-xs text-accent">
                  {data.crescimentoConversas >= 0 ? '+' : ''}{data.crescimentoConversas}% vs mês anterior
                </p>
              </CardContent>
            </Card>
            
            <Card data-testid="kpi-agendamentos">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Agendamentos</CardTitle>
                <i className="fas fa-calendar-check text-accent"></i>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{data.agendamentos}</div>
                <p className="text-xs text-accent">
                  {data.crescimentoAgendamentos >= 0 ? '+' : ''}{data.crescimentoAgendamentos}% vs mês anterior
                </p>
              </CardContent>
            </Card>
            
            <Card data-testid="kpi-conversao">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Taxa de Conversão</CardTitle>
                <i className="fas fa-chart-line text-destructive"></i>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{data.conversaoRate.toFixed(1)}%</div>
                <p className="text-xs text-accent">
                  {data.crescimentoConversao >= 0 ? '+' : ''}{data.crescimentoConversao}% vs mês anterior
                </p>
              </CardContent>
            </Card>
            
            <Card data-testid="kpi-receita">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Receita Estimada</CardTitle>
                <i className="fas fa-dollar-sign text-accent"></i>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">R$ {data.receitaGerada.toLocaleString()}</div>
                <p className="text-xs text-accent">
                  {data.crescimentoReceita >= 0 ? '+' : ''}{data.crescimentoReceita}% vs mês anterior
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Conversion Funnel */}
            <Card data-testid="conversion-funnel">
              <CardHeader>
                <CardTitle className="text-lg font-semibold">Funil de Conversão</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Leads Recebidos</span>
                  <span className="font-semibold">{data.conversas.toLocaleString()}</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-primary h-2 rounded-full w-full"></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm">Respostas Automáticas</span>
                  <span className="font-semibold">{Math.round(data.conversas * 0.95).toLocaleString()} (95.0%)</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-primary h-2 rounded-full" style={{width: "95%"}}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm">Interesse Demonstrado</span>
                  <span className="font-semibold">{Math.round(data.conversas * 0.4).toLocaleString()} ({data.conversas > 0 ? ((Math.round(data.conversas * 0.4) / data.conversas) * 100).toFixed(1) : '0.0'}%)</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-accent h-2 rounded-full" style={{width: "40%"}}></div>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-sm">Agendamentos</span>
                  <span className="font-semibold">{data.agendamentos} ({data.conversaoRate.toFixed(1)}%)</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-secondary h-2 rounded-full" style={{width: `${Math.min(data.conversaoRate, 100)}%`}}></div>
                </div>
              </CardContent>
            </Card>
            
            {/* Recent Activities */}
            <Card data-testid="recent-activities">
              <CardHeader>
                <CardTitle className="text-lg font-semibold">Atividades Recentes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {data.recentActivities.length > 0 ? (
                  data.recentActivities.map((activity) => (
                    <div key={activity.id} className="flex items-start space-x-3">
                      <div className={`${activity.bgColor} p-1 rounded-full`}>
                        <i className={`${activity.icon} text-secondary-foreground text-xs`}></i>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{activity.title}</p>
                        <p className="text-xs text-muted-foreground">{activity.description}</p>
                      </div>
                      <span className="text-xs text-muted-foreground">{activity.time}</span>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4">
                    <p className="text-sm text-muted-foreground">Nenhuma atividade recente</p>
                    <p className="text-xs text-muted-foreground mt-1">Suas primeiras conversas aparecerão aqui</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* ROI Summary */}
          <div className="bg-gradient-to-r from-primary to-accent p-6 rounded-xl text-white" data-testid="roi-summary">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold">R$ {data.roi.monthlyInvestment.toLocaleString()}</div>
                <div className="text-primary-foreground/80 text-sm">Investimento Mensal</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">R$ {data.roi.estimatedRevenue.toLocaleString()}</div>
                <div className="text-primary-foreground/80 text-sm">Receita Estimada</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold">{data.roi.roiPercentage >= 0 ? '+' : ''}{data.roi.roiPercentage}%</div>
                <div className="text-primary-foreground/80 text-sm">ROI em 30 dias</div>
              </div>
            </div>
            {data.conversas === 0 && (
              <div className="mt-4 p-3 bg-white/10 rounded-lg">
                <p className="text-sm text-center">
                  📈 Comece a receber leads para ver seu ROI real em ação!
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
