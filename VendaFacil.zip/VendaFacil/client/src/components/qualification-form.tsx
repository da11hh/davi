import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const qualificationSchema = z.object({
  companySize: z.string().min(1, "Selecione o tamanho da empresa"),
  revenue: z.string().min(1, "Selecione a faixa de faturamento"),
  leadsVolume: z.string().min(1, "Selecione o volume de leads"),
  painPoint: z.string().min(1, "Selecione sua maior dor"),
  timeline: z.string().min(1, "Selecione o timeline"),
  name: z.string().min(2, "Nome é obrigatório"),
  company: z.string().min(2, "Nome da empresa é obrigatório"),
  phone: z.string().regex(
    /^(?:\+55\s?)?(?:\(?[1-9]{2}\)?\s?)?(?:9\d{4}[\-\s]?\d{4}|\d{4}[\-\s]?\d{4})$/,
    "Telefone deve ter formato brasileiro válido (ex: (11) 99999-9999)"
  ),
  email: z.string().email("Email deve ter formato válido"),
  lgpdConsent: z.boolean().refine(val => val === true, {
    message: "Você deve aceitar os termos de privacidade"
  }),
});

type QualificationForm = z.infer<typeof qualificationSchema>;

export default function QualificationForm() {
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 7;
  const { toast } = useToast();

  const form = useForm<QualificationForm>({
    resolver: zodResolver(qualificationSchema),
    defaultValues: {
      companySize: "",
      revenue: "",
      leadsVolume: "",
      painPoint: "",
      timeline: "",
      name: "",
      company: "",
      phone: "",
      email: "",
      lgpdConsent: undefined,
    },
  });

  const onSubmit = async (data: QualificationForm) => {
    try {
      // Ensure LGPD consent is provided
      if (!data.lgpdConsent) {
        toast({
          title: "Consentimento LGPD obrigatório",
          description: "Você deve aceitar a política de privacidade para continuar.",
          variant: "destructive",
        });
        return;
      }

      // Submit data with LGPD consent (score calculated server-side)
      const response = await apiRequest("POST", "/api/leads", { 
        ...data,
        lgpdConsent: true,
        lgpdConsentDate: new Date().toISOString()
      });
      
      toast({
        title: "Qualificação enviada com sucesso!",
        description: "Sua proposta personalizada será enviada em até 2 horas.",
      });

      // Reset form
      form.reset();
      setCurrentStep(1);
    } catch (error: any) {
      const message = error?.response?.data?.message || error.message || "Erro desconhecido";
      toast({
        title: "Erro ao enviar qualificação",
        description: message,
        variant: "destructive",
      });
    }
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const progress = (currentStep / totalSteps) * 100;

  return (
    <section className="py-20 bg-muted/30">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4" data-testid="qualification-title">Vamos Qualificar Sua Empresa</h2>
          <p className="text-xl text-muted-foreground">Responda algumas perguntas para recebermos sua proposta personalizada</p>
          <div className="mt-4 text-sm text-muted-foreground">
            <i className="fas fa-clock mr-1"></i>
            Leva apenas 2 minutos
          </div>
        </div>
        
        <div className="bg-card border border-border rounded-2xl p-8 shadow-lg">
          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex justify-between text-sm text-muted-foreground mb-2">
              <span>Pergunta <span data-testid="current-question">{currentStep}</span> de {totalSteps}</span>
              <span><span data-testid="progress-percent">{Math.round(progress)}</span>% concluído</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300" 
                style={{ width: `${progress}%` }}
                data-testid="progress-bar"
              ></div>
            </div>
          </div>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              {/* Step 1: Company Size */}
              {currentStep === 1 && (
                <div data-testid="step-company-size">
                  <h3 className="text-xl font-semibold mb-4">Qual o tamanho da sua empresa?</h3>
                  <FormField
                    control={form.control}
                    name="companySize"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            value={field.value}
                            className="space-y-3"
                          >
                            {[
                              { value: "solo", label: "Empresário individual (apenas eu)" },
                              { value: "small", label: "2-10 funcionários" },
                              { value: "medium", label: "11-50 funcionários" },
                              { value: "large", label: "50+ funcionários" }
                            ].map((option) => (
                              <div key={option.value} className="flex items-center p-4 border border-input rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                                <RadioGroupItem value={option.value} id={option.value} className="mr-3" />
                                <FormLabel htmlFor={option.value} className="cursor-pointer flex-1">{option.label}</FormLabel>
                              </div>
                            ))}
                          </RadioGroup>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              )}

              {/* Step 2: Revenue */}
              {currentStep === 2 && (
                <div data-testid="step-revenue">
                  <h3 className="text-xl font-semibold mb-4">Qual seu faturamento mensal aproximado?</h3>
                  <FormField
                    control={form.control}
                    name="revenue"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            value={field.value}
                            className="space-y-3"
                          >
                            {[
                              { value: "low", label: "Até R$ 50.000" },
                              { value: "medium", label: "R$ 50.000 - R$ 300.000" },
                              { value: "high", label: "R$ 300.000 - R$ 1.000.000" },
                              { value: "enterprise", label: "Mais de R$ 1.000.000" }
                            ].map((option) => (
                              <div key={option.value} className="flex items-center p-4 border border-input rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                                <RadioGroupItem value={option.value} id={option.value} className="mr-3" />
                                <FormLabel htmlFor={option.value} className="cursor-pointer flex-1">{option.label}</FormLabel>
                              </div>
                            ))}
                          </RadioGroup>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              )}

              {/* Step 3: Leads Volume */}
              {currentStep === 3 && (
                <div data-testid="step-leads-volume">
                  <h3 className="text-xl font-semibold mb-4">Quantos leads você recebe mensalmente pelo WhatsApp?</h3>
                  <FormField
                    control={form.control}
                    name="leadsVolume"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            value={field.value}
                            className="space-y-3"
                          >
                            {[
                              { value: "low", label: "Menos de 50" },
                              { value: "medium", label: "50 - 200" },
                              { value: "high", label: "200 - 500" },
                              { value: "enterprise", label: "Mais de 500" }
                            ].map((option) => (
                              <div key={option.value} className="flex items-center p-4 border border-input rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                                <RadioGroupItem value={option.value} id={option.value} className="mr-3" />
                                <FormLabel htmlFor={option.value} className="cursor-pointer flex-1">{option.label}</FormLabel>
                              </div>
                            ))}
                          </RadioGroup>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              )}

              {/* Step 4: Pain Point */}
              {currentStep === 4 && (
                <div data-testid="step-pain-point">
                  <h3 className="text-xl font-semibold mb-4">Qual sua maior dor no atendimento atual?</h3>
                  <FormField
                    control={form.control}
                    name="painPoint"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            value={field.value}
                            className="space-y-3"
                          >
                            {[
                              { value: "delay", label: "Demora para responder leads (perda de vendas)" },
                              { value: "followup", label: "Não consigo fazer follow-up consistente" },
                              { value: "scheduling", label: "Agendamento manual toma muito tempo" },
                              { value: "24h", label: "Não consigo atender 24h/7 dias" }
                            ].map((option) => (
                              <div key={option.value} className="flex items-center p-4 border border-input rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                                <RadioGroupItem value={option.value} id={option.value} className="mr-3" />
                                <FormLabel htmlFor={option.value} className="cursor-pointer flex-1">{option.label}</FormLabel>
                              </div>
                            ))}
                          </RadioGroup>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              )}

              {/* Step 5: Timeline */}
              {currentStep === 5 && (
                <div data-testid="step-timeline">
                  <h3 className="text-xl font-semibold mb-4">Quando você gostaria de implementar a solução?</h3>
                  <FormField
                    control={form.control}
                    name="timeline"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            value={field.value}
                            className="space-y-3"
                          >
                            {[
                              { value: "immediate", label: "Imediatamente (esta semana)" },
                              { value: "month", label: "Próximo mês" },
                              { value: "quarter", label: "Próximo trimestre" },
                              { value: "exploring", label: "Ainda estou pesquisando opções" }
                            ].map((option) => (
                              <div key={option.value} className="flex items-center p-4 border border-input rounded-lg hover:bg-muted/50 cursor-pointer transition-colors">
                                <RadioGroupItem value={option.value} id={option.value} className="mr-3" />
                                <FormLabel htmlFor={option.value} className="cursor-pointer flex-1">{option.label}</FormLabel>
                              </div>
                            ))}
                          </RadioGroup>
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              )}

              {/* Step 6: Contact Info */}
              {currentStep === 6 && (
                <div data-testid="step-contact-info">
                  <h3 className="text-xl font-semibold mb-4">Seus dados para recebermos a proposta personalizada:</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome completo *</FormLabel>
                          <FormControl>
                            <Input placeholder="Seu nome" {...field} data-testid="input-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Empresa *</FormLabel>
                          <FormControl>
                            <Input placeholder="Nome da empresa" {...field} data-testid="input-company" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>WhatsApp *</FormLabel>
                          <FormControl>
                            <Input placeholder="(11) 99999-9999" {...field} data-testid="input-phone" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email *</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="seu@email.com" {...field} data-testid="input-email" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              )}

              {/* Step 7: LGPD Consent */}
              {currentStep === 7 && (
                <div data-testid="step-lgpd-consent">
                  <h3 className="text-xl font-semibold mb-6">Proteção de Dados e Privacidade</h3>
                  <div className="bg-muted/30 border border-border rounded-lg p-6 mb-6">
                    <h4 className="font-semibold mb-4">Política de Privacidade - LGPD</h4>
                    <div className="text-sm text-muted-foreground space-y-3">
                      <p>Em conformidade com a Lei Geral de Proteção de Dados (LGPD), informamos:</p>
                      <ul className="list-disc list-inside space-y-1">
                        <li>Seus dados serão usados exclusivamente para elaborar uma proposta personalizada</li>
                        <li>Não compartilhamos informações com terceiros sem sua autorização</li>
                        <li>Você pode solicitar a exclusão dos seus dados a qualquer momento</li>
                        <li>Utilizamos medidas de segurança para proteger suas informações</li>
                        <li>Seus dados ficaram armazenados por até 2 anos para fins comerciais</li>
                      </ul>
                      <p className="font-medium">Para exercer seus direitos ou esclarecer dúvidas sobre privacidade, entre em contato conosco.</p>
                    </div>
                  </div>
                  <FormField
                    control={form.control}
                    name="lgpdConsent"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-lgpd-consent"
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel className="text-sm font-normal cursor-pointer">
                            Li e aceito a política de privacidade e autorizo o tratamento dos meus dados pessoais conforme descrito acima, em conformidade com a LGPD. *
                          </FormLabel>
                          <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
              )}
              
              {/* Navigation Buttons */}
              <div className="flex justify-between">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={prevStep}
                  className={currentStep === 1 ? "invisible" : ""}
                  data-testid="button-previous"
                >
                  <i className="fas fa-arrow-left mr-2"></i>
                  Anterior
                </Button>
                
                <div className="flex-1"></div>
                
                {currentStep < totalSteps ? (
                  <Button 
                    type="button" 
                    onClick={nextStep}
                    data-testid="button-next"
                  >
                    Próxima
                    <i className="fas fa-arrow-right ml-2"></i>
                  </Button>
                ) : (
                  <Button 
                    type="submit"
                    className="bg-accent text-accent-foreground hover:bg-accent/90"
                    data-testid="button-submit"
                  >
                    <i className="fas fa-paper-plane mr-2"></i>
                    Receber Proposta
                  </Button>
                )}
              </div>
            </form>
          </Form>
        </div>
      </div>
    </section>
  );
}
