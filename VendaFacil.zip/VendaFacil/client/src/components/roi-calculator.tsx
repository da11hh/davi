import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";

interface ROIResults {
  lostLeads: number;
  lostRevenue: number;
  timeCost: number;
  totalSavings: number;
  roi: number;
}

export default function ROICalculator() {
  const [leads, setLeads] = useState(150);
  const [ticket, setTicket] = useState(800);
  const [hours, setHours] = useState(4);
  const [businessType, setBusinessType] = useState("consulting");
  const [results, setResults] = useState<ROIResults>({
    lostLeads: 102,
    lostRevenue: 81600,
    timeCost: 4800,
    totalSavings: 86400,
    roi: 17366
  });

  const calculateROI = async () => {
    try {
      const response = await apiRequest("POST", "/api/calculate-roi", {
        leads,
        ticket,
        hours,
        businessType
      });
      const data = await response.json();
      setResults(data);
    } catch (error) {
      console.error("Error calculating ROI:", error);
    }
  };

  useEffect(() => {
    calculateROI();
  }, [leads, ticket, hours, businessType]);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4" data-testid="roi-calculator-title">Calcule Seu ROI em 30 Segundos</h2>
          <p className="text-xl text-muted-foreground">Descubra quanto você pode economizar com automação inteligente</p>
        </div>
        
        <div className="bg-card border border-border rounded-2xl p-8 shadow-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Calculator Inputs */}
            <div className="space-y-6">
              <div>
                <Label htmlFor="leads-month" className="block text-sm font-medium mb-2">
                  Quantos leads você recebe por mês no WhatsApp?
                </Label>
                <Input
                  id="leads-month"
                  type="number"
                  value={leads}
                  onChange={(e) => setLeads(parseInt(e.target.value) || 0)}
                  placeholder="Ex: 150"
                  data-testid="input-leads"
                />
              </div>
              
              <div>
                <Label htmlFor="ticket-average" className="block text-sm font-medium mb-2">
                  Qual seu ticket médio? (R$)
                </Label>
                <Input
                  id="ticket-average"
                  type="number"
                  value={ticket}
                  onChange={(e) => setTicket(parseFloat(e.target.value) || 0)}
                  placeholder="Ex: 800"
                  data-testid="input-ticket"
                />
              </div>
              
              <div>
                <Label htmlFor="hours-day" className="block text-sm font-medium mb-2">
                  Quantas horas por dia você gasta respondendo WhatsApp?
                </Label>
                <Select value={hours.toString()} onValueChange={(value) => setHours(parseInt(value))}>
                  <SelectTrigger data-testid="select-hours">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2">2 horas</SelectItem>
                    <SelectItem value="4">4 horas</SelectItem>
                    <SelectItem value="6">6 horas</SelectItem>
                    <SelectItem value="8">8+ horas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="business-type" className="block text-sm font-medium mb-2">
                  Seu tipo de negócio:
                </Label>
                <Select value={businessType} onValueChange={setBusinessType}>
                  <SelectTrigger data-testid="select-business-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="clinic">Clínica/Consultório</SelectItem>
                    <SelectItem value="law">Escritório de Advocacia</SelectItem>
                    <SelectItem value="consulting">Consultoria B2B</SelectItem>
                    <SelectItem value="ecommerce">E-commerce</SelectItem>
                    <SelectItem value="services">Outros Serviços</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button onClick={calculateROI} className="w-full" size="lg" data-testid="button-calculate-roi">
                <i className="fas fa-calculator mr-2"></i>
                Calcular Meu ROI
              </Button>
            </div>
            
            {/* Results Display */}
            <div className="bg-muted/30 p-6 rounded-xl">
              <h3 className="text-xl font-bold mb-6 text-center">Seu Potencial de Economia</h3>
              
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg border border-border" data-testid="result-lost-leads">
                  <div className="text-sm text-muted-foreground">Leads Perdidos por Demora</div>
                  <div className="text-2xl font-bold text-destructive">{results.lostLeads} leads/mês</div>
                </div>
                
                <div className="bg-white p-4 rounded-lg border border-border" data-testid="result-lost-revenue">
                  <div className="text-sm text-muted-foreground">Receita Perdida Mensal</div>
                  <div className="text-2xl font-bold text-destructive">R$ {results.lostRevenue.toLocaleString('pt-BR')}</div>
                </div>
                
                <div className="bg-white p-4 rounded-lg border border-border" data-testid="result-time-cost">
                  <div className="text-sm text-muted-foreground">Custo do Seu Tempo</div>
                  <div className="text-2xl font-bold text-orange-600">R$ {results.timeCost.toLocaleString('pt-BR')}/mês</div>
                </div>
                
                <div className="bg-accent p-4 rounded-lg text-white" data-testid="result-total-savings">
                  <div className="text-sm text-accent-foreground/80">Economia Total com IA</div>
                  <div className="text-3xl font-bold">R$ {results.totalSavings.toLocaleString('pt-BR')}/mês</div>
                </div>
                
                <div className="bg-primary p-4 rounded-lg text-white" data-testid="result-annual-roi">
                  <div className="text-sm text-primary-foreground/80">ROI em 12 meses</div>
                  <div className="text-3xl font-bold">{results.roi.toLocaleString('pt-BR')}%</div>
                </div>
              </div>
              
              <Button className="w-full mt-6 bg-accent text-accent-foreground hover:bg-accent/90" data-testid="button-start-now">
                Quero Começar Agora
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
