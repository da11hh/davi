import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CalendarIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const demoBookingSchema = z.object({
  name: z.string().min(2, "Nome é obrigatório"),
  email: z.string().email("Email deve ter formato válido"),
  phone: z.string().regex(
    /^(?:\+55\s?)?(?:\(?[1-9]{2}\)?\s?)?(?:9\d{4}[\-\s]?\d{4}|\d{4}[\-\s]?\d{4})$/,
    "Telefone deve ter formato brasileiro válido (ex: (11) 99999-9999)"
  ),
  company: z.string().min(2, "Nome da empresa é obrigatório"),
  demoDate: z.date({ required_error: "Selecione uma data para o demo" }),
  timeSlot: z.string().min(1, "Selecione um horário"),
  demoType: z.string().min(1, "Selecione o tipo de demonstração"),
  notes: z.string().optional(),
});

type DemoBookingForm = z.infer<typeof demoBookingSchema>;

interface DemoBookingProps {
  leadId?: string;
  onSuccess?: () => void;
  onCancel?: () => void;
  className?: string;
}

export default function DemoBookingForm({ leadId, onSuccess, onCancel, className }: DemoBookingProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<DemoBookingForm>({
    resolver: zodResolver(demoBookingSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      company: "",
      demoDate: undefined,
      timeSlot: "",
      demoType: "",
      notes: "",
    },
  });

  // Available time slots
  const timeSlots = [
    { value: "09:00", label: "09:00 - 09:30" },
    { value: "10:00", label: "10:00 - 10:30" },
    { value: "11:00", label: "11:00 - 11:30" },
    { value: "14:00", label: "14:00 - 14:30" },
    { value: "15:00", label: "15:00 - 15:30" },
    { value: "16:00", label: "16:00 - 16:30" },
    { value: "17:00", label: "17:00 - 17:30" },
  ];

  // Demo types
  const demoTypes = [
    { 
      value: "full", 
      label: "Demonstração Completa",
      description: "30 min - Visão geral completa da plataforma e configuração personalizada",
      duration: "30 min"
    },
    { 
      value: "quick", 
      label: "Demo Rápido",
      description: "15 min - Principais funcionalidades e ROI específico para seu negócio",
      duration: "15 min"
    },
    { 
      value: "technical", 
      label: "Demo Técnico",
      description: "45 min - Integração WhatsApp, configurações avançadas e treinamento",
      duration: "45 min"
    },
  ];

  // Disable past dates and weekends
  const isDateDisabled = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dayOfWeek = date.getDay();
    return date < today || dayOfWeek === 0 || dayOfWeek === 6; // Disable past dates and weekends
  };

  const onSubmit = async (data: DemoBookingForm) => {
    setIsSubmitting(true);
    try {
      // Combine date and time into scheduled timestamp
      const [hours, minutes] = data.timeSlot.split(':').map(Number);
      const scheduledDate = new Date(data.demoDate);
      scheduledDate.setHours(hours, minutes, 0, 0);

      const demoData = {
        leadId: leadId || null,
        scheduledDate: scheduledDate.toISOString(),
        notes: `${data.demoType} - ${data.notes || ''}`.trim(),
        // Include contact info in notes if no leadId
        ...(!leadId && {
          notes: `${data.demoType} | Contato: ${data.name} (${data.email}, ${data.phone}) - ${data.company} | ${data.notes || ''}`.trim()
        })
      };

      await apiRequest("POST", "/api/demos", demoData);

      toast({
        title: "Demo agendado com sucesso!",
        description: `Seu demo foi agendado para ${format(scheduledDate, "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}. Você receberá um email de confirmação em breve.`,
      });

      // Reset form
      form.reset();
      
      // Call success callback
      if (onSuccess) {
        onSuccess();
      }
    } catch (error: any) {
      const message = error?.response?.data?.message || error.message || "Erro desconhecido";
      toast({
        title: "Erro ao agendar demo",
        description: message,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className={cn("w-full max-w-2xl mx-auto", className)}>
      <CardHeader>
        <CardTitle className="text-2xl text-center" data-testid="demo-booking-title">
          <i className="fas fa-calendar-plus text-primary mr-2"></i>
          Agendar Demonstração Personalizada
        </CardTitle>
        <p className="text-center text-muted-foreground">
          Escolha o melhor horário para ver a Secretária IA funcionando no seu negócio
        </p>
      </CardHeader>
      
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Contact Information */}
            {!leadId && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome completo *</FormLabel>
                      <FormControl>
                        <Input placeholder="Seu nome" {...field} data-testid="input-demo-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Empresa *</FormLabel>
                      <FormControl>
                        <Input placeholder="Nome da empresa" {...field} data-testid="input-demo-company" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email *</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="seu@email.com" {...field} data-testid="input-demo-email" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>WhatsApp *</FormLabel>
                      <FormControl>
                        <Input placeholder="(11) 99999-9999" {...field} data-testid="input-demo-phone" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            {/* Demo Type Selection */}
            <FormField
              control={form.control}
              name="demoType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tipo de Demonstração *</FormLabel>
                  <FormControl>
                    <div className="space-y-3">
                      {demoTypes.map((demo) => (
                        <div
                          key={demo.value}
                          className={cn(
                            "border border-input rounded-lg p-4 cursor-pointer transition-colors",
                            field.value === demo.value 
                              ? "border-primary bg-primary/5" 
                              : "hover:bg-muted/50"
                          )}
                          onClick={() => field.onChange(demo.value)}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-3">
                              <input
                                type="radio"
                                checked={field.value === demo.value}
                                onChange={() => field.onChange(demo.value)}
                                className="text-primary"
                                data-testid={`radio-demo-type-${demo.value}`}
                              />
                              <Label className="font-semibold cursor-pointer">{demo.label}</Label>
                            </div>
                            <Badge variant="outline">{demo.duration}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground ml-6">{demo.description}</p>
                        </div>
                      ))}
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Date Picker */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="demoDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data da Demonstração *</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                            data-testid="button-select-date"
                          >
                            {field.value ? (
                              format(field.value, "PPP", { locale: ptBR })
                            ) : (
                              <span>Selecione uma data</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={isDateDisabled}
                          initialFocus
                          locale={ptBR}
                          data-testid="calendar-demo-date"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Time Slot Selection */}
              <FormField
                control={form.control}
                name="timeSlot"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Horário *</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        value={field.value}
                        className="grid grid-cols-2 gap-2"
                      >
                        {timeSlots.map((slot) => (
                          <div key={slot.value} className="flex items-center space-x-2 border border-input rounded-md px-3 py-2 hover:bg-muted/50 cursor-pointer">
                            <RadioGroupItem 
                              value={slot.value} 
                              id={`time-${slot.value}`}
                              data-testid={`radio-time-${slot.value}`}
                            />
                            <Label 
                              htmlFor={`time-${slot.value}`} 
                              className="cursor-pointer text-sm flex-1"
                            >
                              {slot.label}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Additional Notes */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Observações (opcional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Alguma informação específica sobre seu negócio ou dúvidas que gostaria de esclarecer..."
                      className="resize-none"
                      {...field}
                      data-testid="textarea-demo-notes"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Action Buttons */}
            <div className="flex justify-between gap-4">
              {onCancel && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  disabled={isSubmitting}
                  data-testid="button-cancel-demo"
                >
                  Cancelar
                </Button>
              )}
              
              <Button
                type="submit"
                className="flex-1 bg-primary hover:bg-primary/90"
                disabled={isSubmitting}
                data-testid="button-schedule-demo"
              >
                {isSubmitting ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Agendando...
                  </>
                ) : (
                  <>
                    <i className="fas fa-calendar-check mr-2"></i>
                    Agendar Demonstração
                  </>
                )}
              </Button>
            </div>

            {/* Help Text */}
            <div className="bg-muted/30 border border-border rounded-lg p-4 text-center">
              <p className="text-sm text-muted-foreground">
                <i className="fas fa-info-circle mr-1 text-primary"></i>
                Você receberá um email de confirmação com o link da reunião. 
                Também entraremos em contato via WhatsApp para confirmar o agendamento.
              </p>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}