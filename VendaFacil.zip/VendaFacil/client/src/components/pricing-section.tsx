import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useLocation } from "wouter";

interface PricingPlan {
  id: string;
  name: string;
  monthlyPrice: number;
  annualPrice: number;
  description: string;
  features: string[];
  popular?: boolean;
  buttonText: string;
  buttonVariant: "default" | "outline";
}

const plans: PricingPlan[] = [
  {
    id: "starter",
    name: "Starter",
    monthlyPrice: 297,
    annualPrice: 238, // 20% off
    description: "Para pequenos negócios iniciando a automação",
    features: [
      "500 conversas/mês",
      "Agendamentos ilimitados",
      "Gravação de reuniões",
      "Relatórios básicos",
      "Suporte via chat"
    ],
    buttonText: "Começar Teste Grátis",
    buttonVariant: "outline"
  },
  {
    id: "professional",
    name: "Professional",
    monthlyPrice: 597,
    annualPrice: 478, // 20% off
    description: "Para empresas que querem escalar rapidamente",
    features: [
      "Conversas ilimitadas",
      "Multi-usuários (até 5)",
      "Integrações CRM",
      "API personalizada",
      "Onboarding dedicado",
      "Suporte prioritário"
    ],
    popular: true,
    buttonText: "Começar Teste Grátis",
    buttonVariant: "default"
  },
  {
    id: "enterprise",
    name: "Enterprise",
    monthlyPrice: 1497,
    annualPrice: 1198, // 20% off
    description: "Para grandes empresas com necessidades específicas",
    features: [
      "Tudo do Professional",
      "White label",
      "Customizações específicas",
      "SLA 99,9%",
      "Success Manager",
      "Treinamento da equipe"
    ],
    buttonText: "Falar com Vendas",
    buttonVariant: "outline"
  },
  {
    id: "custom",
    name: "Customizado",
    monthlyPrice: 0,
    annualPrice: 0,
    description: "Solução personalizada para suas necessidades específicas",
    features: [
      "Volume ilimitado",
      "Integração completa",
      "Desenvolvimento dedicado",
      "Suporte 24/7",
      "Consultoria estratégica"
    ],
    buttonText: "Solicitar Orçamento",
    buttonVariant: "default"
  }
];

export default function PricingSection() {
  const [isAnnual, setIsAnnual] = useState(false);
  const [, setLocation] = useLocation();

  const handlePlanSelect = (plan: PricingPlan) => {
    if (plan.id === "custom" || plan.id === "enterprise") {
      // Redirect to contact or custom quote
      window.open("https://wa.me/5511999999999?text=Gostaria%20de%20mais%20informações%20sobre%20o%20plano%20" + plan.name, "_blank");
    } else {
      // Redirect to checkout
      setLocation(`/checkout?plan=${plan.id}&annual=${isAnnual}`);
    }
  };

  return (
    <section id="pricing" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4" data-testid="pricing-title">Planos que Cabem no Seu Orçamento</h2>
          <p className="text-xl text-muted-foreground mb-8">Escolha o plano ideal para o tamanho do seu negócio</p>
          
          <div className="flex items-center justify-center space-x-4 mb-8">
            <span className="text-muted-foreground">Mensal</span>
            <Switch
              checked={isAnnual}
              onCheckedChange={setIsAnnual}
              data-testid="annual-toggle"
            />
            <span className="text-muted-foreground">
              Anual <span className="text-accent font-semibold">(20% off)</span>
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`bg-card rounded-2xl p-6 hover:shadow-lg transition-shadow relative ${
                plan.popular ? "border-2 border-primary" : "border border-border"
              } ${plan.id === "custom" ? "bg-gradient-to-br from-primary/5 to-accent/5 border-2 border-dashed border-primary/30" : ""}`}
              data-testid={`plan-${plan.id}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                    Mais Popular
                  </span>
                </div>
              )}
              
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">{plan.name}</h3>
                <div className="mb-4">
                  {plan.id === "custom" ? (
                    <span className="text-3xl font-bold">Sob consulta</span>
                  ) : (
                    <>
                      <span className="text-3xl font-bold">
                        R$ {isAnnual ? plan.annualPrice : plan.monthlyPrice}
                      </span>
                      <span className="text-muted-foreground">/mês</span>
                    </>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mb-6">{plan.description}</p>
              </div>
              
              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <i className="fas fa-check text-accent mr-2"></i>
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button
                className="w-full"
                variant={plan.buttonVariant}
                onClick={() => handlePlanSelect(plan)}
                data-testid={`button-select-${plan.id}`}
              >
                {plan.buttonText}
              </Button>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">Todos os planos incluem:</p>
          <div className="flex flex-wrap justify-center gap-6 text-sm">
            <span className="flex items-center">
              <i className="fas fa-shield-alt text-accent mr-2"></i>LGPD Compliant
            </span>
            <span className="flex items-center">
              <i className="fas fa-lock text-accent mr-2"></i>SSL Certificate
            </span>
            <span className="flex items-center">
              <i className="fas fa-headset text-accent mr-2"></i>Suporte especializado
            </span>
            <span className="flex items-center">
              <i className="fas fa-sync text-accent mr-2"></i>Backup automático
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
