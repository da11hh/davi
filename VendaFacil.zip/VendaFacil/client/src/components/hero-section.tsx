import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section className="hero-gradient pt-20 pb-16 text-foreground relative overflow-hidden">
      <div className="absolute inset-0 bg-black/10"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center glass-effect rounded-full px-4 py-2 mb-6" data-testid="hero-badge">
              <span className="text-sm font-medium text-foreground">✨ Mais de 127 empresas já economizam R$ 2.847/mês</span>
            </div>
            <h1 className="text-4xl lg:text-6xl font-bold leading-tight mb-6 text-foreground" data-testid="hero-title">
              PARE de Perder<br/>
              <span className="text-accent">R$ 2.847/Mês</span><br/>
              em Clientes
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed" data-testid="hero-description">
              Transforme seu WhatsApp em uma <strong className="text-foreground">Secretária IA 24/7</strong> que agenda reuniões, faz follow-ups e converte leads automaticamente - sem contratar funcionários.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90" size="lg" data-testid="hero-demo-button">
                <i className="fas fa-play mr-2"></i>
                Ver Demo ao Vivo (2min)
              </Button>
              <Button variant="outline" className="glass-effect text-foreground hover:bg-muted border-border" size="lg" data-testid="hero-roi-button">
                <i className="fas fa-calculator mr-2"></i>
                Calcular Meu ROI
              </Button>
            </div>
            <div className="flex items-center space-x-6 text-sm text-muted-foreground" data-testid="hero-features">
              <div className="flex items-center">
                <i className="fas fa-check-circle mr-2 text-accent"></i>
                Setup em 15 minutos
              </div>
              <div className="flex items-center">
                <i className="fas fa-shield-alt mr-2 text-accent"></i>
                LGPD Compliant
              </div>
              <div className="flex items-center">
                <i className="fas fa-clock mr-2 text-accent"></i>
                7 dias grátis
              </div>
            </div>
          </div>
          <div className="relative">
            {/* WhatsApp Demo Preview */}
            <div className="glass-effect rounded-2xl p-6 animate-float" data-testid="hero-demo-card">
              <div className="bg-accent p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <i className="fab fa-whatsapp text-accent-foreground text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-center mb-4 text-foreground">Demo Ao Vivo</h3>
              <div className="space-y-3">
                <div className="bg-muted p-3 rounded-lg border border-border">
                  <p className="text-sm text-muted-foreground">📱 "Olá! Gostaria de agendar uma consulta"</p>
                </div>
                <div className="bg-accent/20 p-3 rounded-lg border-l-4 border-accent">
                  <p className="text-sm text-foreground">🤖 "Claro! Que tal terça às 14h? Já agendei na sua agenda."</p>
                </div>
              </div>
              <Button className="w-full mt-4 bg-accent text-accent-foreground hover:bg-accent/90" data-testid="hero-test-button">
                Testar Agora
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
