import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  sentiment?: {
    rating: number;
    confidence: number;
  };
  quickReplies?: string[];
  intent?: string;
  conversationState?: any;
}

interface ConversationState {
  phase: 'introduction' | 'discovery' | 'qualification' | 'objections' | 'closing' | 'demo_booking';
  businessType?: string;
  painPoints?: string[];
  leadScore?: number;
  lastIntent?: string;
}

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: "Olá! 👋 Sou especialista em automação WhatsApp da Secretária IA. Ajudo empresas a converter mais leads em clientes. \n\nQual é o seu tipo de negócio?",
      timestamp: new Date(),
      quickReplies: ["Clínica/Consultório", "E-commerce", "Imobiliária", "Agência", "Outro"]
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [conversationState, setConversationState] = useState<ConversationState>({ phase: 'introduction' });
  const [showQuickReplies, setShowQuickReplies] = useState(true);
  const { toast } = useToast();

  const sendMessage = async (messageText?: string) => {
    const messageToSend = messageText || inputValue;
    if (!messageToSend.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      role: "user",
      content: messageToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);
    setShowQuickReplies(false);

    try {
      const response = await apiRequest("POST", "/api/chat", {
        message: messageToSend,
        sessionId: sessionId,
        leadId: null
      });

      const data = await response.json();

      const aiMessage: ChatMessage = {
        role: "assistant",
        content: data.response,
        timestamp: new Date(),
        sentiment: data.sentiment,
        quickReplies: data.quickReplies,
        intent: data.intent?.category,
        conversationState: data.conversationState
      };

      setMessages(prev => [...prev, aiMessage]);
      setSessionId(data.sessionId);
      
      // Update conversation state
      if (data.conversationState) {
        setConversationState(data.conversationState);
      }
      
      // Show quick replies if available
      if (data.quickReplies && data.quickReplies.length > 0) {
        setShowQuickReplies(true);
      }
    } catch (error) {
      toast({
        title: "Erro no chat",
        description: "Não foi possível enviar a mensagem. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleQuickReply = (reply: string) => {
    sendMessage(reply);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };
  
  const getPhaseIndicator = (phase: string) => {
    const phaseMap = {
      'introduction': '👋 Introdução',
      'discovery': '🔍 Descoberta',
      'qualification': '📊 Qualificação',
      'objections': '💬 Negociação',
      'closing': '🎯 Fechamento',
      'demo_booking': '📅 Agendamento'
    };
    return phaseMap[phase as keyof typeof phaseMap] || '🚀 Atendimento';
  };
  
  const getLatestQuickReplies = () => {
    const lastAssistantMessage = messages.filter(m => m.role === 'assistant').slice(-1)[0];
    return lastAssistantMessage?.quickReplies || [];
  };

  return (
    <div className="fixed bottom-6 right-6 z-50" data-testid="chat-widget">
      {/* Chat Bubble */}
      <div
        className={`bg-accent text-accent-foreground p-4 rounded-full shadow-lg cursor-pointer hover:bg-accent/90 transition-colors ${
          isOpen ? "hidden" : "block"
        }`}
        onClick={() => setIsOpen(true)}
        data-testid="chat-bubble"
      >
        <i className="fas fa-comments text-xl"></i>
      </div>
      
      {/* Chat Window */}
      <div
        className={`absolute bottom-16 right-0 w-96 bg-white dark:bg-gray-900 border border-border rounded-2xl shadow-2xl overflow-hidden ${
          isOpen ? "block" : "hidden"
        }`}
        data-testid="chat-window"
      >
        {/* Chat Header */}
        <div className="bg-primary text-primary-foreground p-4 flex justify-between items-center">
          <div className="flex-1">
            <h4 className="font-semibold">Assistente de Vendas IA</h4>
            <p className="text-primary-foreground/80 text-sm">
              {getPhaseIndicator(conversationState.phase)}
            </p>
            {conversationState.leadScore && conversationState.leadScore > 0 && (
              <div className="text-xs text-primary-foreground/70 mt-1">
                Score: {conversationState.leadScore}/100
              </div>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" title="Online"></div>
            <Button
              variant="ghost"
              size="sm"
              className="text-primary-foreground/80 hover:text-primary-foreground p-1"
              onClick={() => setIsOpen(false)}
              data-testid="chat-close"
            >
              <i className="fas fa-times"></i>
            </Button>
          </div>
        </div>
        
        {/* Chat Messages */}
        <div className="p-4 h-80 overflow-y-auto bg-muted/10 space-y-3" data-testid="chat-messages">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`max-w-sm ${
                message.role === "assistant" 
                  ? "bg-primary/10 p-3 rounded-lg" 
                  : "bg-white dark:bg-gray-800 p-3 rounded-lg ml-auto border border-border"
              }`}
            >
              <p className="text-sm whitespace-pre-line">{message.content}</p>
              <div className="flex justify-between items-center mt-2">
                <span className="text-xs text-muted-foreground">
                  {message.timestamp.toLocaleTimeString('pt-BR', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </span>
                {message.sentiment && message.role === 'user' && (
                  <span className="text-xs text-muted-foreground">
                    {message.sentiment.rating >= 4 ? '😊' : 
                     message.sentiment.rating <= 2 ? '😔' : '😐'}
                  </span>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="bg-primary/10 p-3 rounded-lg max-w-sm">
              <div className="flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                  <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                </div>
                <span className="text-xs text-muted-foreground">Analisando...</span>
              </div>
            </div>
          )}
          
          {/* Quick Replies */}
          {showQuickReplies && !isLoading && getLatestQuickReplies().length > 0 && (
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground">Respostas rápidas:</p>
              <div className="flex flex-wrap gap-2">
                {getLatestQuickReplies().map((reply, index) => (
                  <button
                    key={index}
                    onClick={() => handleQuickReply(reply)}
                    className="text-xs bg-primary/5 hover:bg-primary/10 border border-primary/20 rounded-full px-3 py-1 transition-colors text-left"
                    data-testid={`quick-reply-${index}`}
                  >
                    {reply}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {/* Chat Input */}
        <div className="p-4 border-t border-border bg-white dark:bg-gray-900">
          <div className="flex space-x-2">
            <Input
              type="text"
              placeholder={isLoading ? "Aguarde..." : "Digite sua pergunta..."}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1 text-sm"
              disabled={isLoading}
              data-testid="chat-input"
            />
            <Button
              onClick={() => sendMessage()}
              disabled={isLoading || !inputValue.trim()}
              size="sm"
              data-testid="chat-send"
              className="flex items-center"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <i className="fas fa-paper-plane text-sm"></i>
              )}
            </Button>
          </div>
          {conversationState.businessType && (
            <div className="mt-2 text-xs text-muted-foreground">
              Detectado: {conversationState.businessType} | Fase: {conversationState.phase}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
