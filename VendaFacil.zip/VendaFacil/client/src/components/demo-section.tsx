import { useState } from "react";
import { Button } from "@/components/ui/button";

interface Message {
  id: number;
  type: "user" | "ai";
  content: string;
  time: string;
}

export default function DemoSection() {
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, type: "user", content: "Olá! Gostaria de agendar uma consulta", time: "14:23" },
    { id: 2, type: "ai", content: "Olá! Claro, vou te ajudar a agendar. Qual é o melhor dia e horário para você?", time: "14:23" },
    { id: 3, type: "user", content: "Terça-feira à tarde seria perfeito", time: "14:24" },
    { id: 4, type: "ai", content: "Perfeito! Tenho disponibilidade na terça às 14h ou às 16h. Qual prefere?", time: "14:24" },
    { id: 5, type: "user", content: "14h está ótimo!", time: "14:25" },
    { id: 6, type: "ai", content: "✅ Agendado! Terça, 14h. Acabei de enviar um convite para seu email com o link da reunião. Até lá!", time: "14:25" }
  ]);

  const [isPlaying, setIsPlaying] = useState(false);

  const playDemo = () => {
    setIsPlaying(true);
    setMessages([]);
    
    // Simulate typing messages one by one
    const demoMessages = [
      { id: 1, type: "user", content: "Olá! Gostaria de agendar uma consulta", time: "14:23" },
      { id: 2, type: "ai", content: "Olá! Claro, vou te ajudar a agendar. Qual é o melhor dia e horário para você?", time: "14:23" },
      { id: 3, type: "user", content: "Terça-feira à tarde seria perfeito", time: "14:24" },
      { id: 4, type: "ai", content: "Perfeito! Tenho disponibilidade na terça às 14h ou às 16h. Qual prefere?", time: "14:24" },
      { id: 5, type: "user", content: "14h está ótimo!", time: "14:25" },
      { id: 6, type: "ai", content: "✅ Agendado! Terça, 14h. Acabei de enviar um convite para seu email com o link da reunião. Até lá!", time: "14:25" }
    ] as Message[];

    demoMessages.forEach((message, index) => {
      setTimeout(() => {
        setMessages(prev => [...prev, message]);
        if (index === demoMessages.length - 1) {
          setIsPlaying(false);
        }
      }, (index + 1) * 1500);
    });
  };

  return (
    <section id="demo" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4" data-testid="demo-title">Veja Funcionando ao Vivo</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Nossa IA não apenas responde mensagens - ela entende contexto, agenda reuniões e faz follow-ups inteligentes.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* WhatsApp Demo Interface */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden" data-testid="whatsapp-demo">
            {/* WhatsApp Header */}
            <div className="bg-secondary px-6 py-4 flex items-center space-x-3">
              <div className="bg-white/20 p-2 rounded-full">
                <i className="fas fa-robot text-white"></i>
              </div>
              <div className="flex-1">
                <div className="font-semibold text-white">Secretária IA</div>
                <div className="text-secondary-foreground/80 text-sm">online</div>
              </div>
              <i className="fas fa-phone text-white"></i>
              <i className="fas fa-video text-white"></i>
            </div>
            
            {/* Chat Container */}
            <div className="chat-container bg-muted/50 p-4 space-y-3 min-h-[300px]">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.type === "ai" ? "justify-end" : ""}`}>
                  <div className={`p-3 rounded-lg max-w-xs shadow-sm message-bubble ${
                    message.type === "ai" 
                      ? "bg-secondary text-secondary-foreground" 
                      : "bg-card"
                  }`}>
                    <p className="text-sm">{message.content}</p>
                    <span className={`text-xs mt-1 block ${
                      message.type === "ai" ? "text-secondary-foreground/70" : "text-muted-foreground"
                    }`}>{message.time}</span>
                  </div>
                </div>
              ))}
              {isPlaying && (
                <div className="flex justify-end">
                  <div className="bg-secondary text-secondary-foreground p-3 rounded-lg max-w-xs">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-secondary-foreground rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-secondary-foreground rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                      <div className="w-2 h-2 bg-secondary-foreground rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* Action Buttons */}
            <div className="p-4 border-t border-border">
              <Button 
                className="w-full" 
                onClick={playDemo} 
                disabled={isPlaying}
                data-testid="start-demo-button"
              >
                <i className="fas fa-play mr-2"></i>
                {isPlaying ? "Reproduzindo Demo..." : "Iniciar Demo Personalizada"}
              </Button>
            </div>
          </div>
          
          {/* Features Highlight */}
          <div className="space-y-6">
            <div className="bg-card border border-border p-6 rounded-xl" data-testid="feature-contextual">
              <div className="flex items-start space-x-4">
                <div className="bg-primary/10 p-3 rounded-lg">
                  <i className="fas fa-brain text-primary text-xl"></i>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">Inteligência Contextual</h3>
                  <p className="text-muted-foreground">Entende o contexto da conversa e responde de forma natural e personalizada.</p>
                </div>
              </div>
            </div>
            
            <div className="bg-card border border-border p-6 rounded-xl" data-testid="feature-scheduling">
              <div className="flex items-start space-x-4">
                <div className="bg-accent/10 p-3 rounded-lg">
                  <i className="fas fa-calendar-plus text-accent text-xl"></i>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">Agendamento Automático</h3>
                  <p className="text-muted-foreground">Agenda reuniões automaticamente na sua agenda e envia convites por email.</p>
                </div>
              </div>
            </div>
            
            <div className="bg-card border border-border p-6 rounded-xl" data-testid="feature-followup">
              <div className="flex items-start space-x-4">
                <div className="bg-orange-100 p-3 rounded-lg">
                  <i className="fas fa-follow text-orange-600 text-xl"></i>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">Follow-up Inteligente</h3>
                  <p className="text-muted-foreground">Faz follow-ups personalizados no momento certo para maximizar conversões.</p>
                </div>
              </div>
            </div>
            
            <div className="bg-card border border-border p-6 rounded-xl" data-testid="feature-analytics">
              <div className="flex items-start space-x-4">
                <div className="bg-accent/10 p-3 rounded-lg">
                  <i className="fas fa-chart-line text-accent text-xl"></i>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">Analytics em Tempo Real</h3>
                  <p className="text-muted-foreground">Dashboard completo com métricas de conversão e ROI trackeable.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
