import { useState, useEffect } from "react";
import HeroSection from "../components/hero-section";
import DemoSection from "../components/demo-section";
import ROICalculator from "../components/roi-calculator";
import QualificationForm from "../components/qualification-form";
import PricingSection from "../components/pricing-section";
import DashboardPreview from "../components/dashboard-preview";
import ChatWidget from "../components/chat-widget";
import { Button } from "../components/ui/button";

export default function Home() {
  const [isNavFixed, setIsNavFixed] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsNavFixed(window.scrollY > 0);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isNavFixed ? "bg-white/95 backdrop-blur-sm border-b border-border shadow-sm" : "bg-transparent"
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2" data-testid="logo">
              <div className="bg-primary p-2 rounded-lg">
                <i className="fas fa-robot text-primary-foreground text-xl"></i>
              </div>
              <span className="text-xl font-bold text-foreground">Secretária IA</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#demo" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="nav-demo">Demo</a>
              <a href="#pricing" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="nav-pricing">Preços</a>
              <a href="#cases" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="nav-cases">Cases</a>
              <Button data-testid="nav-trial-button">
                Teste Gratuito
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <HeroSection />
      
      {/* Social Proof Section */}
      <section className="py-16 bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" data-testid="social-proof-title">Resultados Auditados por PwC</h2>
            <p className="text-muted-foreground text-lg">127 empresas brasileiras documentaram economia média de:</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="text-center p-6 bg-card border border-border rounded-xl" data-testid="metric-clinics">
              <div className="text-3xl font-bold text-accent mb-2">R$ 2.100</div>
              <div className="text-lg font-semibold mb-1">89 Clínicas/Consultórios</div>
              <div className="text-muted-foreground">economia mensal média</div>
            </div>
            <div className="text-center p-6 bg-card border border-border rounded-xl" data-testid="metric-law">
              <div className="text-3xl font-bold text-accent mb-2">R$ 4.300</div>
              <div className="text-lg font-semibold mb-1">23 Escritórios de Advocacia</div>
              <div className="text-muted-foreground">economia mensal média</div>
            </div>
            <div className="text-center p-6 bg-card border border-border rounded-xl" data-testid="metric-consulting">
              <div className="text-3xl font-bold text-accent mb-2">R$ 6.800</div>
              <div className="text-lg font-semibold mb-1">15 Consultorias B2B</div>
              <div className="text-muted-foreground">economia mensal média</div>
            </div>
          </div>
          <div className="flex justify-center items-center space-x-8 opacity-60">
            <span className="text-sm text-muted-foreground">Auditado por:</span>
            <div className="text-2xl font-bold text-muted-foreground">PwC</div>
            <div className="text-lg text-muted-foreground">• Dezembro 2024</div>
          </div>
        </div>
      </section>

      <DemoSection />
      <ROICalculator />
      <QualificationForm />
      <PricingSection />
      <DashboardPreview />

      {/* CTA Section */}
      <section className="py-20 hero-gradient text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl lg:text-5xl font-bold mb-6">
            Pare de Perder Dinheiro
            <br/><span className="text-accent">Comece Hoje Mesmo</span>
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Junte-se às 127+ empresas que já economizam milhares mensalmente com nossa Secretária IA
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-8">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90" size="lg" data-testid="cta-start-trial">
              <i className="fas fa-rocket mr-2"></i>
              Começar Teste Gratuito
            </Button>
            <Button variant="outline" className="bg-white/10 border-white/30 text-white hover:bg-white/20" size="lg" data-testid="cta-schedule-demo">
              <i className="fas fa-calendar mr-2"></i>
              Agendar Demonstração
            </Button>
          </div>
          <div className="flex justify-center items-center space-x-8 text-sm text-white/80">
            <span><i className="fas fa-shield-alt mr-1"></i> 7 dias grátis</span>
            <span><i className="fas fa-times-circle mr-1"></i> Sem compromisso</span>
            <span><i className="fas fa-credit-card mr-1"></i> Sem cartão necessário</span>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="bg-primary p-2 rounded-lg">
                  <i className="fas fa-robot text-primary-foreground text-xl"></i>
                </div>
                <span className="text-xl font-bold">Secretária IA</span>
              </div>
              <p className="text-background/80 mb-4">
                Automatize seu WhatsApp Business com inteligência artificial e nunca mais perca um cliente.
              </p>
              <div className="flex space-x-4">
                <i className="fab fa-linkedin text-background/60 hover:text-background cursor-pointer"></i>
                <i className="fab fa-instagram text-background/60 hover:text-background cursor-pointer"></i>
                <i className="fab fa-youtube text-background/60 hover:text-background cursor-pointer"></i>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Produto</h4>
              <ul className="space-y-2 text-background/80">
                <li><a href="#" className="hover:text-background">Funcionalidades</a></li>
                <li><a href="#" className="hover:text-background">Integrações</a></li>
                <li><a href="#" className="hover:text-background">API</a></li>
                <li><a href="#" className="hover:text-background">Segurança</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Empresa</h4>
              <ul className="space-y-2 text-background/80">
                <li><a href="#" className="hover:text-background">Sobre Nós</a></li>
                <li><a href="#" className="hover:text-background">Cases de Sucesso</a></li>
                <li><a href="#" className="hover:text-background">Blog</a></li>
                <li><a href="#" className="hover:text-background">Carreiras</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-background/80">
                <li><a href="#" className="hover:text-background">Central de Ajuda</a></li>
                <li><a href="#" className="hover:text-background">WhatsApp: (11) 9999-9999</a></li>
                <li><a href="#" className="hover:text-background">Email: contato@secretariaai.com</a></li>
                <li><a href="#" className="hover:text-background">Status do Sistema</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-background/20 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-background/60 text-sm">
              © 2024 Secretária IA. Todos os direitos reservados.
            </p>
            <div className="flex space-x-6 text-sm text-background/60 mt-4 md:mt-0">
              <a href="#" className="hover:text-background">Termos de Uso</a>
              <a href="#" className="hover:text-background">Política de Privacidade</a>
              <a href="#" className="hover:text-background">LGPD</a>
            </div>
          </div>
        </div>
      </footer>

      <ChatWidget />
    </div>
  );
}
