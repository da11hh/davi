import { useState } from 'react';
import { useLocation } from 'wouter';
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface PlanInfo {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  features: string[];
  popular?: boolean;
}

const plans: Record<string, PlanInfo> = {
  starter: {
    id: "starter",
    name: "Starter",
    price: 297,
    originalPrice: 297,
    features: [
      "500 conversas/mês",
      "Agendamentos ilimitados", 
      "Gravação de reuniões",
      "Relatórios básicos",
      "Suporte via chat"
    ]
  },
  professional: {
    id: "professional", 
    name: "Professional",
    price: 597,
    originalPrice: 597,
    features: [
      "Conversas ilimitadas",
      "Multi-usuários (até 5)",
      "Integrações CRM", 
      "API personalizada",
      "Onboarding dedicado",
      "Suporte prioritário"
    ],
    popular: true
  },
  enterprise: {
    id: "enterprise",
    name: "Enterprise", 
    price: 1497,
    originalPrice: 1497,
    features: [
      "Tudo do Professional",
      "White label",
      "Customizações específicas",
      "SLA 99,9%",
      "Success Manager", 
      "Treinamento da equipe"
    ]
  }
};

const CheckoutForm = ({ plan, isAnnual }: { plan: PlanInfo, isAnnual: boolean }) => {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    cardNumber: '',
    expiry: '',
    cvv: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simular processamento de pagamento
    setTimeout(() => {
      toast({
        title: "✅ Pagamento Simulado Aprovado!",
        description: `Plano ${plan.name} ativado com sucesso! Esta é uma demonstração da plataforma.`,
      });
      setIsProcessing(false);
      
      // Redirecionar para home após sucesso
      setTimeout(() => {
        setLocation('/');
      }, 2000);
    }, 2000);
  };

  const finalPrice = isAnnual ? Math.round(plan.price * 0.8) : plan.price;
  const discount = isAnnual ? Math.round(plan.price * 0.2 * 12) : 0;

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="bg-primary p-2 rounded-lg">
              <i className="fas fa-robot text-primary-foreground text-xl"></i>
            </div>
            <span className="text-2xl font-bold text-foreground">Secretária IA</span>
          </div>
          <h1 className="text-3xl font-bold mb-2" data-testid="checkout-title">
            Finalizar Assinatura - Plano {plan.name}
          </h1>
          <p className="text-muted-foreground">
            Complete seu pagamento para começar a automatizar seu WhatsApp Business
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Plan Summary */}
          <div>
            <Card className={plan.popular ? "border-primary" : ""}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">{plan.name}</CardTitle>
                  {plan.popular && <Badge className="bg-primary">Mais Popular</Badge>}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Pricing */}
                <div className="text-center py-4">
                  {isAnnual && (
                    <div className="text-sm text-muted-foreground line-through">
                      R$ {plan.originalPrice}/mês
                    </div>
                  )}
                  <div className="text-3xl font-bold">
                    R$ {finalPrice.toLocaleString('pt-BR')}
                    <span className="text-base text-muted-foreground font-normal">/mês</span>
                  </div>
                  {isAnnual && (
                    <div className="text-sm text-accent font-semibold mt-1">
                      Economia de R$ {discount.toLocaleString('pt-BR')}/ano
                    </div>
                  )}
                  <div className="text-sm text-muted-foreground mt-2">
                    {isAnnual ? "Cobrança anual" : "Cobrança mensal"}
                  </div>
                </div>

                {/* Features */}
                <div>
                  <h4 className="font-semibold mb-3">Incluído no plano:</h4>
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <i className="fas fa-check text-accent mr-2"></i>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Guarantees */}
                <div className="bg-muted/30 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2 text-sm">Garantias incluídas:</h4>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <i className="fas fa-shield-alt text-accent mr-2"></i>
                      7 dias de teste gratuito
                    </div>
                    <div className="flex items-center">
                      <i className="fas fa-undo text-accent mr-2"></i>
                      Cancelamento a qualquer momento
                    </div>
                    <div className="flex items-center">
                      <i className="fas fa-headset text-accent mr-2"></i>
                      Suporte especializado
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Form */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Dados de Pagamento</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Pagamento seguro processado pelo Stripe
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Informações Pessoais */}
                  <div className="space-y-4">
                    <h4 className="font-semibold text-sm">Informações de Contato</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Nome Completo</Label>
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="Seu nome completo"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                          placeholder="seu@email.com"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">WhatsApp</Label>
                        <Input
                          id="phone"
                          value={formData.phone}
                          onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                          placeholder="(11) 99999-9999"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="company">Empresa</Label>
                        <Input
                          id="company"
                          value={formData.company}
                          onChange={(e) => setFormData(prev => ({ ...prev, company: e.target.value }))}
                          placeholder="Nome da empresa"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Dados do Cartão (Simulado) */}
                  <div className="space-y-4">
                    <h4 className="font-semibold text-sm">Dados do Cartão (Demonstração)</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="md:col-span-2">
                        <Label htmlFor="cardNumber">Número do Cartão</Label>
                        <Input
                          id="cardNumber"
                          value={formData.cardNumber}
                          onChange={(e) => setFormData(prev => ({ ...prev, cardNumber: e.target.value }))}
                          placeholder="1234 5678 9012 3456"
                          maxLength={19}
                        />
                      </div>
                      <div>
                        <Label htmlFor="expiry">Validade</Label>
                        <Input
                          id="expiry"
                          value={formData.expiry}
                          onChange={(e) => setFormData(prev => ({ ...prev, expiry: e.target.value }))}
                          placeholder="MM/AA"
                          maxLength={5}
                        />
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground bg-yellow-50 p-3 rounded-lg">
                      <i className="fas fa-info-circle mr-1"></i>
                      <strong>Demonstração:</strong> Esta é uma simulação. Nenhum pagamento real será processado.
                    </div>
                  </div>
                  
                  <Button 
                    type="submit" 
                    disabled={isProcessing} 
                    className="w-full" 
                    size="lg"
                    data-testid="submit-payment"
                  >
                    {isProcessing ? (
                      <>
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                        Processando Demonstração...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-eye mr-2"></i>
                        Simular Pagamento - R$ {finalPrice.toLocaleString('pt-BR')}/mês
                      </>
                    )}
                  </Button>
                  
                  <div className="text-center text-xs text-muted-foreground">
                    <p>
                      <i className="fas fa-shield-alt mr-1"></i>
                      Pagamento seguro e criptografado
                    </p>
                    <p className="mt-1">
                      Ao confirmar, você concorda com nossos 
                      <a href="#" className="text-primary hover:underline ml-1">Termos de Serviço</a>
                    </p>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Support */}
            <div className="mt-6 text-center">
              <p className="text-sm text-muted-foreground mb-2">
                Precisa de ajuda? Fale conosco:
              </p>
              <div className="flex justify-center space-x-4 text-sm">
                <a 
                  href="https://wa.me/5511999999999" 
                  className="text-accent hover:underline flex items-center"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <i className="fab fa-whatsapp mr-1"></i>
                  WhatsApp
                </a>
                <a 
                  href="mailto:suporte@secretariaai.com" 
                  className="text-accent hover:underline flex items-center"
                >
                  <i className="fas fa-envelope mr-1"></i>
                  Email
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function Checkout() {
  const [error, setError] = useState("");
  const [, setLocation] = useLocation();

  // Parse URL params
  const urlParams = new URLSearchParams(window.location.search);
  const planId = urlParams.get('plan') || 'professional';
  const isAnnual = urlParams.get('annual') === 'true';

  const plan = plans[planId];

  if (error || !plan) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <i className="fas fa-exclamation-triangle text-destructive text-4xl mb-4"></i>
            <h1 className="text-xl font-bold text-foreground mb-2">Erro no Checkout</h1>
            <p className="text-muted-foreground mb-4">
              {error || "Plano não encontrado"}
            </p>
            <Button onClick={() => setLocation("/")} data-testid="back-home">
              <i className="fas fa-arrow-left mr-2"></i>
              Voltar ao Início
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <CheckoutForm plan={plan} isAnnual={isAnnual} />;
}
