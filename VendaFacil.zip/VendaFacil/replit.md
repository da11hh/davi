# WhatsApp AI Assistant Platform

## Overview

This project is a B2B SaaS platform that provides AI-powered WhatsApp business automation solutions. The system offers an AI secretary service that can handle customer conversations, schedule meetings, manage leads, and process payments through WhatsApp Business API integration. The platform is designed as a modern full-stack web application with React frontend, Express backend, and PostgreSQL database using Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for build tooling
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and dark mode support
- **State Management**: TanStack React Query for server state and data fetching
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation for type-safe form handling

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **API Design**: RESTful API with JSON responses and comprehensive error handling
- **File Structure**: Modular route handling with separate storage and business logic layers

### Data Storage Solutions
- **Primary Database**: PostgreSQL hosted on Neon Database
- **ORM**: Drizzle ORM with TypeScript schema definitions
- **Schema Design**: Normalized tables for users, leads, chat sessions, demos, and subscriptions
- **Migration Strategy**: Drizzle Kit for database schema migrations

### Authentication and Authorization
- **Session Management**: Express sessions with PostgreSQL session store (connect-pg-simple)
- **User Model**: Username/password authentication with email verification
- **Payment Integration**: Stripe customer and subscription management

### AI and Chat Features
- **AI Provider**: OpenAI GPT-5 integration for conversational AI
- **Sentiment Analysis**: Real-time message sentiment scoring for lead qualification
- **Chat Management**: Persistent chat sessions with message history and context
- **Lead Scoring**: Automated lead qualification based on conversation analysis

## External Dependencies

### Third-Party Services
- **Database**: Neon Database (PostgreSQL hosting)
- **AI Services**: OpenAI API for GPT-5 language model
- **Payment Processing**: Stripe for subscription billing and payment intents
- **Email Services**: SendGrid for transactional email delivery
- **WhatsApp Integration**: WhatsApp Business API for message handling

### Development Tools
- **Build System**: Vite with TypeScript support and hot module replacement
- **Styling**: PostCSS with Tailwind CSS and Autoprefixer
- **Database Management**: Drizzle Kit for migrations and schema management
- **Replit Integration**: Cartographer and dev banner plugins for Replit environment

### Key NPM Dependencies
- **UI Framework**: React ecosystem with Radix UI components
- **Backend**: Express.js with TypeScript execution via TSX
- **Database**: Drizzle ORM with Neon serverless driver
- **Validation**: Zod for schema validation and type safety
- **Payments**: Stripe SDK for both client and server-side integration
- **Utilities**: Date-fns for date manipulation, clsx for conditional styling