import OpenAI from "openai";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY environment variable must be set");
}

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function analyzeSentiment(text: string): Promise<{
  rating: number,
  confidence: number
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content:
            "You are a sentiment analysis expert for sales conversations. Analyze the sentiment of WhatsApp messages from potential clients and provide a rating from 1 to 5 (1=very negative, 2=negative, 3=neutral, 4=positive, 5=very positive) and a confidence score between 0 and 1. Consider context like buying intent, urgency, and objections. Respond with JSON in this format: { 'rating': number, 'confidence': number }",
        },
        {
          role: "user",
          content: text,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      rating: Math.max(1, Math.min(5, Math.round(result.rating || 3))),
      confidence: Math.max(0, Math.min(1, result.confidence || 0.5)),
    };
  } catch (error) {
    console.error("Error analyzing sentiment:", error);
    return {
      rating: 3,
      confidence: 0.5
    };
  }
}

export async function generateSalesResponse(
  message: string, 
  context: any = {},
  leadData: any = null
): Promise<string> {
  try {
    const systemPrompt = `You are a specialized AI sales assistant for "Secretária IA", a WhatsApp automation service for Brazilian businesses. 

Key product info:
- WhatsApp AI that works 24/7 for lead qualification and appointment scheduling
- Plans: Starter (R$297/mês), Professional (R$597/mês), Enterprise (R$1497/mês), Custom
- Proven ROI: 156% average in 90 days, 127+ companies saved R$2.847/month average
- Real cases: Dr. Silva (clinic) went from 23 to 67 appointments/month

Your personality:
- Professional but friendly Brazilian Portuguese
- Focus on ROI and business results
- Ask qualifying questions to understand their business
- Overcome objections with data and social proof
- Always guide towards a demo or trial

Current conversation context: ${JSON.stringify(context)}
Lead information: ${JSON.stringify(leadData)}

Respond naturally and conversationally, focusing on their specific business needs.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: message,
        },
      ],
      max_tokens: 300,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "Desculpe, não consegui processar sua mensagem. Pode tentar novamente?";
  } catch (error) {
    console.error("Error generating sales response:", error);
    return "Obrigado pelo seu interesse! Um de nossos especialistas entrará em contato em breve. Enquanto isso, que tal agendar uma demonstração gratuita?";
  }
}

export async function qualifyLead(responses: any): Promise<{
  score: number;
  recommendation: string;
  priority: 'high' | 'medium' | 'low';
}> {
  try {
    const prompt = `Analyze this lead qualification data and provide a score (0-100), recommendation, and priority level.

Lead responses: ${JSON.stringify(responses)}

Scoring criteria:
- Company size: Solo(15pts), Small(25pts), Medium(35pts), Large(30pts)  
- Revenue: Low(10pts), Medium(30pts), High(35pts), Enterprise(25pts)
- Leads volume: Low(10pts), Medium(25pts), High(30pts), Enterprise(15pts)
- Pain point urgency: 24h(20pts), Delay(18pts), Followup(15pts), Scheduling(12pts)
- Timeline: Immediate(20pts), Month(15pts), Quarter(10pts), Exploring(5pts)

Priority: High(70+), Medium(40-69), Low(<40)

Provide specific recommendation for next steps.

Respond with JSON: { "score": number, "recommendation": string, "priority": "high|medium|low" }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      score: Math.max(0, Math.min(100, result.score || 50)),
      recommendation: result.recommendation || "Agendar demonstração personalizada para entender melhor as necessidades específicas.",
      priority: result.priority || 'medium'
    };
  } catch (error) {
    console.error("Error qualifying lead:", error);
    return {
      score: 50,
      recommendation: "Lead qualificado para demonstração. Entrar em contato em até 24h.",
      priority: 'medium'
    };
  }
}
