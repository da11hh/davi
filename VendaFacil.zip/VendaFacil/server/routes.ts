import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { insertLeadSchema, insertChatSessionSchema, insertDemoSchema } from "@shared/schema";
import { EmailNurturingService, startEmailProcessor } from "./email-service";

// Rate limiting store (in-memory for demo - use Redis in production)
const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

// Rate limiting middleware
const rateLimit = (maxRequests: number, windowMs: number) => {
  return (req: any, res: any, next: any) => {
    const clientIP = req.ip || req.connection.remoteAddress || '127.0.0.1';
    const now = Date.now();
    const key = `${clientIP}_${req.path}`;
    
    const current = rateLimitStore.get(key);
    
    if (!current || current.resetTime < now) {
      rateLimitStore.set(key, { count: 1, resetTime: now + windowMs });
      return next();
    }
    
    if (current.count >= maxRequests) {
      return res.status(429).json({ 
        message: "Muitas tentativas. Tente novamente em alguns minutos.",
        retryAfter: Math.ceil((current.resetTime - now) / 1000)
      });
    }
    
    current.count++;
    rateLimitStore.set(key, current);
    next();
  };
};
// Enhanced intelligence system for chat
interface ConversationState {
  phase: 'introduction' | 'discovery' | 'qualification' | 'objections' | 'closing' | 'demo_booking';
  businessType?: string;
  painPoints?: string[];
  leadScore?: number;
  lastIntent?: string;
  roiData?: any;
}

interface UserIntent {
  category: 'pricing' | 'demo' | 'roi' | 'objection' | 'qualification' | 'technical' | 'closing' | 'greeting' | 'business_type';
  confidence: number;
  entities: string[];
  businessType?: string;
  painPoint?: string;
}

// Advanced intent detection using multiple signals
const detectUserIntent = (message: string, conversationHistory: any[] = []): UserIntent => {
  const text = message.toLowerCase();
  
  // Pricing intent patterns
  const pricingPatterns = [
    /preço|valor|custa|caro|barato|investimento|mensalidade|plano/,
    /quanto (custa|é|fica)|valor do|preço do/,
    /orçamento|cotação|proposta comercial/
  ];
  
  // Demo/functionality intent patterns
  const demoPatterns = [
    /demo|demonstração|como funciona|ver funcionando|teste/,
    /mostrar|apresentar|conhecer|testar/,
    /exemplo|agendar|reunião|apresentação/
  ];
  
  // ROI/results intent patterns
  const roiPatterns = [
    /resultado|roi|retorno|economia|economizar/,
    /quanto vou ganhar|vale a pena|compensa/,
    /case|caso de sucesso|cliente|referência/
  ];
  
  // Business type detection
  const businessTypes = {
    'clinica': /clínica|médico|dentista|fisioterapeuta|psicólogo|saúde/,
    'escritorio': /advogado|contabilidade|escritório|consultoria|auditoria/,
    'ecommerce': /loja|e-commerce|vendas online|marketplace|produto/,
    'imobiliaria': /imóvel|corretor|imobiliária|apartamento|casa/,
    'agencia': /agência|marketing|publicidade|design|criativo/,
    'servicos': /serviço|manutenção|reforma|instalação|técnico/,
    'educacao': /escola|curso|educação|ensino|professor|faculdade/,
    'consultoria': /consultor|consultoria|coach|mentoria|treinamento/
  };
  
  // Objection detection
  const objectionPatterns = {
    'price': /caro|muito dinheiro|não tenho|orçamento apertado/,
    'complexity': /complexo|difícil|complicado|não entendo/,
    'time': /não tenho tempo|corrido|ocupado/,
    'trust': /não confio|não acredito|golpe|enganação/,
    'competitors': /concorrente|outro sistema|já uso/
  };
  
  // Check for business type
  let businessType;
  for (const [type, pattern] of Object.entries(businessTypes)) {
    if (pattern.test(text)) {
      businessType = type;
      break;
    }
  }
  
  // Check for pain points
  let painPoint;
  if (/perco lead|não respondo|demora|24h|fim de semana/.test(text)) painPoint = 'response_time';
  else if (/não consigo agendar|agenda|calendário/.test(text)) painPoint = 'scheduling';
  else if (/muito manual|perco tempo|repetitivo/.test(text)) painPoint = 'automation';
  else if (/não sei qualificar|lead ruim|perco tempo/.test(text)) painPoint = 'qualification';
  
  // Determine intent with confidence scoring
  if (pricingPatterns.some(p => p.test(text))) {
    return { category: 'pricing', confidence: 0.9, entities: [], businessType, painPoint };
  }
  
  if (demoPatterns.some(p => p.test(text))) {
    return { category: 'demo', confidence: 0.9, entities: [], businessType, painPoint };
  }
  
  if (roiPatterns.some(p => p.test(text))) {
    return { category: 'roi', confidence: 0.9, entities: [], businessType, painPoint };
  }
  
  // Check for objections
  for (const [type, pattern] of Object.entries(objectionPatterns)) {
    if (pattern.test(text)) {
      return { category: 'objection', confidence: 0.8, entities: [type], businessType, painPoint };
    }
  }
  
  // Greeting patterns
  if (/olá|oi|bom dia|boa tarde|boa noite|preciso de ajuda/.test(text)) {
    return { category: 'greeting', confidence: 0.7, entities: [], businessType, painPoint };
  }
  
  // Business type inquiry
  if (businessType) {
    return { category: 'business_type', confidence: 0.8, entities: [businessType], businessType, painPoint };
  }
  
  // Qualification patterns
  if (/quantos lead|volume|recebo|por mês|whatsapp/.test(text)) {
    return { category: 'qualification', confidence: 0.8, entities: [], businessType, painPoint };
  }
  
  return { category: 'greeting', confidence: 0.5, entities: [], businessType, painPoint };
};

// Generate intelligent responses based on intent and context
const generateContextualResponse = (intent: UserIntent, state: ConversationState, conversationHistory: any[] = []): { response: string, newState: ConversationState, quickReplies?: string[] } => {
  const newState = { ...state };
  
  // Update state based on detected information
  if (intent.businessType) newState.businessType = intent.businessType;
  if (intent.painPoint) {
    if (!newState.painPoints) newState.painPoints = [];
    if (!newState.painPoints.includes(intent.painPoint)) {
      newState.painPoints.push(intent.painPoint);
    }
  }
  newState.lastIntent = intent.category;
  
  let response = "";
  let quickReplies: string[] = [];
  
  switch (intent.category) {
    case 'greeting':
      if (state.phase === 'introduction') {
        response = "Olá! 👋 Sou especialista em automação WhatsApp da Secretária IA. Ajudo empresas a converter mais leads em clientes. \n\nQual é o seu tipo de negócio?";
        quickReplies = ["Clínica/Consultório", "E-commerce", "Imobiliária", "Agência", "Outro"];
        newState.phase = 'discovery';
      }
      break;
      
    case 'business_type':
      const businessResponses = {
        'clinica': "Perfeito! Trabalho muito com clínicas. Dr. Silva, por exemplo, aumentou seus agendamentos de 23 para 67 por mês com nossa automação. \n\nQual seu maior desafio: perder leads fora do horário ou dificuldade para agendar?",
        'ecommerce': "Ótimo! E-commerces que automatizam WhatsApp vendem 73% mais. A Loja do João aumentou o ticket médio em R$ 340 só com follow-up automático. \n\nSeu maior problema é abandono de carrinho ou leads que não convertem?",
        'imobiliaria': "Excelente! Imobiliárias perdem 68% dos leads em 10 minutos. A Imóveis Premium fechou 12 vendas extras só no primeiro mês. \n\nO que mais te preocupa: leads frios ou dificuldade para agendar visitas?",
        'agencia': "Show! Agências que automatizam WhatsApp conseguem mais clientes e entregam melhor. A Agência Digital dobrou os leads qualificados. \n\nSeu gargalo é geração de leads ou qualificação dos prospects?"
      };
      
      response = businessResponses[intent.businessType as keyof typeof businessResponses] || 
                "Entendi! Independente do segmento, a automação WhatsApp pode revolucionar seus resultados. \n\nQue tipo de desafio você enfrenta com leads hoje?";
      
      quickReplies = ["Perco muitos leads", "Demoro para responder", "Difícil agendar", "Leads não qualificados"];
      newState.phase = 'qualification';
      break;
      
    case 'pricing':
      if (!state.businessType) {
        response = "Antes de falar sobre investimento, preciso entender seu negócio para calcular seu ROI real. \n\nQual seu tipo de empresa?";
        quickReplies = ["Clínica", "E-commerce", "Imobiliária", "Agência", "Outro"];
      } else {
        response = `Nossos planos começam em R$ 297/mês, mas antes de falar sobre investimento, que tal calculamos quanto você está PERDENDO sem automação? \n\n${state.businessType === 'clinica' ? 'Clínicas' : 'Empresas do seu segmento'} perdem em média R$ 2.847/mês sem automação. \n\nQuantos leads você recebe por WhatsApp mensalmente?`;
        quickReplies = ["10-30 leads", "30-100 leads", "100+ leads", "Não sei ao certo"];
      }
      newState.phase = 'qualification';
      break;
      
    case 'roi':
      response = "Excelente pergunta! 📊 Nossos clientes documentam ROI médio de 156% em 90 dias. \n\n" +
                (state.businessType === 'clinica' ? "Dr. Silva economizou R$ 2.200/mês só em salário de recepcionista e aumentou agendamentos em 187%." : 
                 "Empresas similares à sua economizam em média R$ 2.847/mês e aumentam conversões em 73%.") +
                "\n\nQuer que eu calcule seu ROI específico? Preciso saber quantos leads você recebe mensalmente.";
      quickReplies = ["Calcular meu ROI", "Ver casos de sucesso", "Agendar demonstração"];
      newState.phase = 'qualification';
      break;
      
    case 'demo':
      response = "Claro! Nossa demonstração personalizada mostra exatamente como a automação funcionaria no seu negócio. \n\n" +
                "Em 15 minutos você verá: \n• Como automatizar o primeiro contato \n• Sistema de qualificação inteligente \n• Agendamento automático \n• Follow-ups que convertem \n\n" +
                "Qual melhor horário para você?";
      quickReplies = ["Manhã (9h-12h)", "Tarde (14h-17h)", "Prefiro escolher"];
      newState.phase = 'demo_booking';
      break;
      
    case 'objection':
      const objectionResponses = {
        'price': "Entendo a preocupação com investimento. Mas veja: se você perde apenas 5 leads por mês por demora na resposta, já são R$ 1.500+ de prejuízo (considerando ticket médio R$ 300). \n\nNosso sistema se paga em menos de 15 dias. Quer calcular seu ROI real?",
        'complexity': "Que bom que perguntou! Nossa solução é plug-and-play. Em 2 horas está funcionando. O Dr. Silva disse: 'Pensei que seria complicado, mas em 1 dia já estava respondendo sozinho'. \n\nQuer ver como é simples na prática?",
        'time': "Perfeito! Justamente para pessoas ocupadas como você que criamos a automação. Você ganha 40h/mês que gastava respondendo WhatsApp. \n\nImplementação é em 2h e depois funciona sozinho. Vale a pena ver, não acha?",
        'trust': "Compreendo totalmente! Por isso temos 7 dias de teste grátis - você só paga se realmente funcionar. Mais de 127 empresas já aprovaram. \n\nQue tal começar com o teste? Sem compromisso.",
        'competitors': "Interessante! Qual sistema você usa? Posso mostrar nossa comparação. Geralmente migramos clientes de outros sistemas porque oferecemos 3x mais automações pelo mesmo preço. \n\nQuer ver as diferenças?"
      };
      
      const objectionType = intent.entities[0] || 'price';
      response = objectionResponses[objectionType as keyof typeof objectionResponses];
      quickReplies = ["Quero calcular ROI", "Ver demonstração", "Teste grátis"];
      break;
      
    case 'qualification':
      response = "Perfeito! Com essas informações consigo calcular seu ROI personalizado. \n\n" +
                "Com base no SEBRAE: 68% dos leads são perdidos após 10 min sem resposta. \n\n" +
                "Você provavelmente está perdendo R$ 1.500-3.000/mês. \n\nQuer ver o cálculo detalhado do seu caso?";
      quickReplies = ["Sim, calcular ROI", "Agendar demonstração", "Ver casos similares"];
      newState.phase = 'closing';
      break;
      
    default:
      response = "Sou especialista em automação WhatsApp que pode revolucionar seus resultados. \n\n" +
                "O que mais te interessa saber: preços, demonstração ou casos de sucesso?";
      quickReplies = ["Ver preços", "Agendar demo", "Casos de sucesso"];
  }
  
  return { response, newState, quickReplies };
};

// Mock sentiment analysis (keeping for compatibility)
const analyzeSentiment = async (text: string) => {
  const positiveWords = ['ótimo', 'excelente', 'bom', 'interessante', 'quero', 'preciso', 'sim', 'perfeito'];
  const negativeWords = ['ruim', 'caro', 'não', 'impossível', 'difícil', 'complicado'];
  
  const lowerText = text.toLowerCase();
  const hasPositive = positiveWords.some(word => lowerText.includes(word));
  const hasNegative = negativeWords.some(word => lowerText.includes(word));
  
  let rating = 3;
  if (hasPositive && !hasNegative) rating = 4;
  if (hasPositive && hasNegative) rating = 3;
  if (!hasPositive && hasNegative) rating = 2;
  if (hasPositive && (lowerText.includes('ótimo') || lowerText.includes('excelente'))) rating = 5;
  
  return { rating, confidence: 0.8 };
};

// Mock Stripe for demo purposes - no real payments processed
const stripe = {
  paymentIntents: {
    create: async (params: any) => ({
      client_secret: `demo_${Date.now()}_client_secret`,
      id: `pi_${Date.now()}`,
      status: 'requires_payment_method'
    })
  },
  customers: {
    create: async (params: any) => ({
      id: `cus_${Date.now()}`,
      email: params.email,
      name: params.name
    })
  },
  subscriptions: {
    create: async (params: any) => ({
      id: `sub_${Date.now()}`,
      latest_invoice: {
        payment_intent: {
          client_secret: `demo_${Date.now()}_subscription_secret`
        }
      }
    })
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Lead qualification and scoring with rate limiting and LGPD compliance
  app.post("/api/leads", rateLimit(5, 300000), async (req, res) => { // 5 requests per 5 minutes
    try {
      // Validate and parse with enhanced LGPD compliance
      const leadData = insertLeadSchema.parse({
        ...req.body,
        lgpdConsentDate: new Date() // Automatically set consent timestamp
      });
      
      // Ensure LGPD consent was provided
      if (!leadData.lgpdConsent) {
        return res.status(400).json({ 
          message: "Consentimento LGPD é obrigatório para processar seus dados"
        });
      }
      
      // Calculate lead score based on qualification answers
      let score = 0;
      
      // Company size scoring
      if (leadData.companySize === "small") score += 25;
      else if (leadData.companySize === "medium") score += 35;
      else if (leadData.companySize === "large") score += 30;
      else score += 15; // solo
      
      // Revenue scoring
      if (leadData.revenue === "medium") score += 30;
      else if (leadData.revenue === "high") score += 35;
      else if (leadData.revenue === "enterprise") score += 25;
      else score += 10; // low
      
      // Volume scoring
      if (leadData.leadsVolume === "medium") score += 25;
      else if (leadData.leadsVolume === "high") score += 30;
      else if (leadData.leadsVolume === "enterprise") score += 15;
      else score += 10; // low
      
      // Timeline urgency scoring
      if (leadData.timeline === "immediate") score += 20;
      else if (leadData.timeline === "month") score += 15;
      else if (leadData.timeline === "quarter") score += 10;
      else score += 5; // exploring
      
      const lead = await storage.createLead({ 
        ...leadData, 
        score,
        lgpdConsent: true,
        lgpdConsentDate: new Date()
      });
      
      // 🎯 AUTO-START EMAIL NURTURING FOR QUALIFIED LEADS
      if (score >= 70) {
        console.log(`🚀 Lead qualificado! Score: ${score} - Iniciando campanha de nurturing para ${lead.name}`);
        
        // Start email nurturing campaign asynchronously
        EmailNurturingService.startCampaignForLead(lead)
          .then(() => {
            console.log(`✅ Campanha de email iniciada para ${lead.name} (${lead.company})`);
          })
          .catch(error => {
            console.error(`❌ Erro ao iniciar campanha de email para ${lead.name}:`, error);
          });
      }
      
      // Return limited data without exposing all PII
      res.json({ 
        id: lead.id, 
        score: lead.score, 
        status: lead.status,
        message: "Qualificação enviada com sucesso! Sua proposta personalizada será enviada em até 2 horas."
      });
    } catch (error: any) {
      res.status(400).json({ message: "Error creating lead: " + error.message });
    }
  });

  // REMOVED: GET /api/leads endpoint for security - PII data should not be exposed
  // Analytics endpoint provides summary data without exposing personal information

  // ROI calculation endpoint
  app.post("/api/calculate-roi", async (req, res) => {
    try {
      const { leads, ticket, hours, businessType } = req.body;
      
      // Calculations based on SEBRAE data: 68% leads lost after 10 min without response
      const lostLeads = Math.round(leads * 0.68);
      const lostRevenue = lostLeads * ticket;
      const timeCost = hours * 30 * 40; // 40 reais/hour estimate
      const totalSavings = lostRevenue + timeCost;
      const annualSavings = totalSavings * 12;
      const investment = 597 * 12; // Professional plan
      const roi = ((annualSavings - investment) / investment * 100);
      
      res.json({
        lostLeads,
        lostRevenue,
        timeCost,
        totalSavings,
        annualSavings,
        roi: Math.round(roi)
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error calculating ROI: " + error.message });
    }
  });

  // Enhanced AI Chat with intelligent conversation management
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, sessionId, leadId } = req.body;
      
      let session;
      if (sessionId) {
        session = await storage.getChatSession(sessionId);
      }
      
      if (!session) {
        session = await storage.createChatSession({
          leadId: leadId || null,
          messages: []
        });
      }
      
      const messages = session.messages as any[] || [];
      const conversationHistory = messages.slice(-6); // Keep last 6 messages for context
      
      // Get or initialize conversation state
      let conversationState: ConversationState = {
        phase: 'introduction',
        ...(session.status ? { phase: session.status as any } : {})
      };
      
      // Extract state from recent messages if available
      const lastAssistantMessage = messages.filter(m => m.role === 'assistant').slice(-1)[0];
      if (lastAssistantMessage && lastAssistantMessage.conversationState) {
        conversationState = lastAssistantMessage.conversationState;
      }
      
      // Detect user intent with enhanced analysis
      const userIntent = detectUserIntent(message, conversationHistory);
      
      // Generate intelligent contextual response
      const { response: aiResponse, newState, quickReplies } = generateContextualResponse(
        userIntent, 
        conversationState, 
        conversationHistory
      );
      
      // Analyze sentiment
      const sentiment = await analyzeSentiment(message);
      
      // Add user message
      messages.push({ 
        role: "user", 
        content: message, 
        timestamp: new Date(),
        intent: userIntent
      });
      
      // Add AI response with enhanced metadata
      messages.push({ 
        role: "assistant", 
        content: aiResponse, 
        timestamp: new Date(),
        sentiment: sentiment,
        conversationState: newState,
        quickReplies: quickReplies,
        intent: userIntent.category
      });
      
      // Update session with new state
      const updatedSession = await storage.updateChatMessages(session.id, messages);
      
      // Calculate lead score if we have enough information
      let leadScore = 0;
      if (newState.businessType) leadScore += 20;
      if (newState.painPoints && newState.painPoints.length > 0) leadScore += 30;
      if (userIntent.category === 'demo' || userIntent.category === 'pricing') leadScore += 25;
      if (sentiment.rating >= 4) leadScore += 25;
      
      newState.leadScore = leadScore;
      
      res.json({
        response: aiResponse,
        sessionId: session.id,
        sentiment: sentiment,
        quickReplies: quickReplies,
        conversationState: newState,
        intent: userIntent,
        leadScore: leadScore
      });
    } catch (error: any) {
      console.error('Chat error:', error);
      res.status(500).json({ message: "Error processing chat: " + error.message });
    }
  });

  // Demo scheduling
  app.post("/api/demos", async (req, res) => {
    try {
      const demoData = insertDemoSchema.parse(req.body);
      const demo = await storage.createDemo(demoData);
      res.json(demo);
    } catch (error: any) {
      res.status(400).json({ message: "Error scheduling demo: " + error.message });
    }
  });

  // Stripe payment routes
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { amount, plan } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "brl",
        metadata: {
          plan: plan
        }
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Subscription creation for recurring plans
  app.post('/api/create-subscription', async (req, res) => {
    try {
      const { email, name, plan, amount } = req.body;
      
      const customer = await stripe.customers.create({
        email: email,
        name: name,
      });

      // Create a subscription setup intent for the customer
      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{
          price_data: {
            currency: 'brl',
            product_data: {
              name: `Secretária IA - Plano ${plan}`,
            },
            unit_amount: Math.round(amount * 100),
            recurring: {
              interval: 'month',
            },
          },
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });

      res.json({
        subscriptionId: subscription.id,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      res.status(400).json({ error: { message: error.message } });
    }
  });

  // Comprehensive analytics dashboard data
  app.get("/api/analytics", async (req, res) => {
    try {
      const growthMetrics = await storage.getGrowthMetrics();
      const recentActivities = await storage.getRecentActivities(10);
      
      // Current month metrics
      const current = growthMetrics.currentMonth;
      const growth = growthMetrics.growth;
      
      // Calculate ROI based on real data
      const monthlyInvestment = 597; // Professional plan cost
      const roi = current.estimatedRevenue > 0 ? ((current.estimatedRevenue - monthlyInvestment) / monthlyInvestment * 100) : 0;
      
      const analyticsData = {
        // Main KPI metrics
        conversas: current.leads,
        agendamentos: current.demos,
        conversaoRate: current.conversions,
        receitaGerada: current.estimatedRevenue,
        
        // Growth percentages
        crescimentoConversas: growth.leads,
        crescimentoAgendamentos: growth.demos,
        crescimentoConversao: growth.conversions,
        crescimentoReceita: growth.revenue,
        
        // Additional analytics for compatibility
        totalLeads: current.leads,
        qualifiedLeads: Math.round(current.leads * 0.6), // Estimate 60% qualification rate
        demos: current.demos,
        conversionRate: current.conversions,
        averageScore: 75, // Reasonable average for qualified leads
        
        // Recent activities
        recentActivities: recentActivities,
        
        // ROI calculation
        roi: {
          monthlyInvestment: monthlyInvestment,
          estimatedRevenue: current.estimatedRevenue,
          roiPercentage: Math.round(roi)
        }
      };
      
      res.json(analyticsData);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching analytics: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
