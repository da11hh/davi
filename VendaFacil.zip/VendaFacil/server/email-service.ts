import { storage } from "./storage";
import type { Lead, EmailTemplate, InsertEmailTemplate } from "@shared/schema";

// Email templates following the methodology from the attached document
const EMAIL_TEMPLATES: InsertEmailTemplate[] = [
  // Email 1 - Boas-vindas (imediato)
  {
    name: "Boas-vindas",
    subject: "🎉 Bem-vindo! Sua demonstração personalizada está pronta",
    templateType: "welcome",
    delayDays: 0,
    isActive: true,
    htmlContent: `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bem-vindo à Secretária IA</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 10px; text-align: center; margin-bottom: 30px;">
        <h1 style="color: white; margin: 0; font-size: 28px;">🎉 Bem-vindo à Secretária IA!</h1>
    </div>
    
    <p>Olá <strong>{{LEAD_NAME}}</strong>,</p>
    
    <p>Muito obrigado por se qualificar para nossa solução! Vi que sua empresa <strong>{{COMPANY_NAME}}</strong> tem potencial de economizar <strong>R$ {{ROI_VALUE}}/mês</strong> com nossa automação.</p>
    
    <p>Preparei uma demonstração personalizada de 5 minutos mostrando exatamente como nossa IA funcionaria no <strong>SEU</strong> negócio.</p>
    
    <div style="text-align: center; margin: 30px 0;">
        <a href="https://cal.com/secretaria-ia/demo" style="background: #667eea; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">VER MINHA DEMONSTRAÇÃO</a>
    </div>
    
    <p>Qualquer dúvida, responda este email.</p>
    
    <p>Abraço,<br>
    <strong>Equipe Secretária IA</strong></p>
    
    <div style="border-top: 1px solid #eee; margin-top: 30px; padding-top: 20px; text-align: center; font-size: 12px; color: #666;">
        <p>Secretária IA - Automação WhatsApp Business com IA<br>
        Se não deseja mais receber esses emails, <a href="#">clique aqui</a></p>
    </div>
</body>
</html>`,
    textContent: `Olá {{LEAD_NAME}},

Muito obrigado por se qualificar para nossa solução! Vi que sua empresa {{COMPANY_NAME}} tem potencial de economizar R$ {{ROI_VALUE}}/mês com nossa automação.

Preparei uma demonstração personalizada de 5 minutos mostrando exatamente como nossa IA funcionaria no SEU negócio.

Link para demonstração: https://cal.com/secretaria-ia/demo

Qualquer dúvida, responda este email.

Abraço,
Equipe Secretária IA`
  },

  // Email 2 - Caso de sucesso (dia 2)
  {
    name: "Caso de Sucesso",
    subject: "Como uma clínica triplicou as consultas em 30 dias",
    templateType: "case_study",
    delayDays: 2,
    isActive: true,
    htmlContent: `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Case de Sucesso - Secretária IA</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 30px;">
        <h1 style="color: #333; margin: 0; font-size: 24px;">📈 Case Real de Sucesso</h1>
    </div>
    
    <p>Oi <strong>{{LEAD_NAME}}</strong>,</p>
    
    <p>Dr. Silva estava perdendo 40% das consultas por cancelamentos e leads que não respondiam...</p>
    
    <div style="background: #e8f5e8; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0; color: #2d5a2d;">✅ Resultados em apenas 30 dias:</h3>
        <ul style="margin: 0;">
            <li><strong>187% mais consultas agendadas</strong></li>
            <li><strong>50% menos cancelamentos</strong></li>
            <li><strong>R$ 8.000 de aumento na receita mensal</strong></li>
            <li><strong>3 horas por dia economizadas</strong></li>
        </ul>
    </div>
    
    <p>O segredo? Nossa IA aprendeu o tom de voz da clínica e automatizou:</p>
    <ul>
        <li>Confirmação de consultas 24h antes</li>
        <li>Reagendamento automático de cancelamentos</li>
        <li>Qualificação de novos pacientes</li>
        <li>Follow-up pós-consulta</li>
    </ul>
    
    <div style="text-align: center; margin: 30px 0;">
        <a href="https://secretariaai.com/case-dr-silva" style="background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">VER CASE COMPLETO</a>
    </div>
    
    <p>Sua empresa {{COMPANY_NAME}} pode ter resultados similares ou até melhores.</p>
    
    <p>Quer conversar sobre como implementar isso no seu negócio?</p>
    
    <p>Abraço,<br>
    <strong>Equipe Secretária IA</strong></p>
</body>
</html>`,
    textContent: `Oi {{LEAD_NAME}},

Dr. Silva estava perdendo 40% das consultas por cancelamentos e leads que não respondiam...

✅ Resultados em apenas 30 dias:
• 187% mais consultas agendadas
• 50% menos cancelamentos  
• R$ 8.000 de aumento na receita mensal
• 3 horas por dia economizadas

O segredo? Nossa IA aprendeu o tom de voz da clínica e automatizou:
- Confirmação de consultas 24h antes
- Reagendamento automático de cancelamentos
- Qualificação de novos pacientes
- Follow-up pós-consulta

Ver case completo: https://secretariaai.com/case-dr-silva

Sua empresa {{COMPANY_NAME}} pode ter resultados similares ou até melhores.

Quer conversar sobre como implementar isso no seu negócio?

Abraço,
Equipe Secretária IA`
  },

  // Email 3 - Educativo (dia 4)
  {
    name: "Educativo - IA Personalizada",
    subject: "Por que sua IA precisa ser treinada especificamente para seu negócio",
    templateType: "educational",
    delayDays: 4,
    isActive: true,
    htmlContent: `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IA Personalizada - Secretária IA</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: #fff3cd; padding: 20px; border-radius: 10px; margin-bottom: 30px; border-left: 4px solid #ffc107;">
        <h1 style="color: #856404; margin: 0; font-size: 24px;">🎯 IA Personalizada vs IA Genérica</h1>
    </div>
    
    <p>Oi <strong>{{LEAD_NAME}}</strong>,</p>
    
    <p>Muita gente pensa que IA é "uma coisa só"...</p>
    
    <p><strong>A verdade:</strong> nossa IA aprende <strong>SEU</strong> vocabulário, <strong>SEU</strong> tom de voz, <strong>SUAS</strong> ofertas.</p>
    
    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0;">🤖 Como treinamos sua IA:</h3>
        <ol>
            <li><strong>Análise de conversas existentes</strong> - A IA aprende como você fala com clientes</li>
            <li><strong>Mapeamento de objeções</strong> - Identificamos as 10 objeções mais comuns do seu setor</li>
            <li><strong>Criação de scripts personalizados</strong> - Cada resposta soa como SE FOSSE VOCÊ falando</li>
            <li><strong>Teste e refinamento</strong> - 7 dias de ajustes baseados em conversas reais</li>
        </ol>
    </div>
    
    <p><strong>Resultado?</strong> Seus clientes não percebem que estão falando com uma IA!</p>
    
    <div style="background: #e8f5e8; padding: 15px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0;"><em>"Achei que era a secretária mesmo! Super educada e sabia responder tudo sobre os preços."</em></p>
        <p style="margin: 5px 0 0 0; font-size: 14px; color: #666;">- Cliente real de uma clínica em SP</p>
    </div>
    
    <div style="text-align: center; margin: 30px 0;">
        <a href="https://secretariaai.com/como-funciona" style="background: #17a2b8; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">VER COMO FUNCIONA (VÍDEO 3 MIN)</a>
    </div>
    
    <p>Para {{COMPANY_NAME}}, isso significa atendimento 24/7 que parece 100% humano.</p>
    
    <p>Abraço,<br>
    <strong>Equipe Secretária IA</strong></p>
</body>
</html>`,
    textContent: `Oi {{LEAD_NAME}},

Muita gente pensa que IA é "uma coisa só"...

A verdade: nossa IA aprende SEU vocabulário, SEU tom de voz, SUAS ofertas.

🤖 Como treinamos sua IA:
1. Análise de conversas existentes - A IA aprende como você fala com clientes
2. Mapeamento de objeções - Identificamos as 10 objeções mais comuns do seu setor  
3. Criação de scripts personalizados - Cada resposta soa como SE FOSSE VOCÊ falando
4. Teste e refinamento - 7 dias de ajustes baseados em conversas reais

Resultado? Seus clientes não percebem que estão falando com uma IA!

"Achei que era a secretária mesmo! Super educada e sabia responder tudo sobre os preços."
- Cliente real de uma clínica em SP

Ver como funciona: https://secretariaai.com/como-funciona

Para {{COMPANY_NAME}}, isso significa atendimento 24/7 que parece 100% humano.

Abraço,
Equipe Secretária IA`
  },

  // Email 4 - ROI e economia (dia 7)
  {
    name: "ROI e Economia",
    subject: "Calcule exatamente quanto você vai economizar",
    templateType: "roi",
    delayDays: 7,
    isActive: true,
    htmlContent: `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora ROI - Secretária IA</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: #d4edda; padding: 20px; border-radius: 10px; margin-bottom: 30px; border-left: 4px solid #28a745;">
        <h1 style="color: #155724; margin: 0; font-size: 24px;">💰 Sua Economia Detalhada</h1>
    </div>
    
    <p>Oi <strong>{{LEAD_NAME}}</strong>,</p>
    
    <p>Fiz as contas para você baseado no perfil da {{COMPANY_NAME}}:</p>
    
    <div style="background: #fff; border: 2px solid #28a745; padding: 25px; border-radius: 10px; margin: 20px 0; text-align: center;">
        <h2 style="color: #dc3545; margin: 0 0 10px 0; font-size: 28px;">- R$ {{ROI_VALUE}}/mês</h2>
        <p style="margin: 0; color: #666; font-size: 18px;">em custos que você está perdendo SEM automação</p>
    </div>
    
    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0;">📊 Breakdown dos custos:</h3>
        <table style="width: 100%; border-collapse: collapse;">
            <tr style="border-bottom: 1px solid #dee2e6;">
                <td style="padding: 10px 0;">Salário recepcionista/atendente</td>
                <td style="padding: 10px 0; text-align: right; font-weight: bold;">R$ 2.500</td>
            </tr>
            <tr style="border-bottom: 1px solid #dee2e6;">
                <td style="padding: 10px 0;">Leads perdidos (fora do horário)</td>
                <td style="padding: 10px 0; text-align: right; font-weight: bold;">R$ 1.800</td>
            </tr>
            <tr style="border-bottom: 1px solid #dee2e6;">
                <td style="padding: 10px 0;">Reagendamentos manuais</td>
                <td style="padding: 10px 0; text-align: right; font-weight: bold;">R$ 900</td>
            </tr>
            <tr style="border-bottom: 1px solid #dee2e6;">
                <td style="padding: 10px 0;">Qualificação inadequada</td>
                <td style="padding: 10px 0; text-align: right; font-weight: bold;">R$ 650</td>
            </tr>
            <tr style="background: #f8d7da; font-weight: bold;">
                <td style="padding: 15px 0;">TOTAL MENSAL PERDIDO:</td>
                <td style="padding: 15px 0; text-align: right; color: #dc3545; font-size: 18px;">R$ 5.850</td>
            </tr>
        </table>
    </div>
    
    <div style="background: #d1ecf1; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0; text-align: center;">
            <strong>Nossa solução: R$ 297/mês</strong><br>
            <span style="color: #28a745; font-size: 24px; font-weight: bold;">SUA ECONOMIA: R$ 5.553/mês</span>
        </p>
    </div>
    
    <div style="text-align: center; margin: 30px 0;">
        <a href="https://secretariaai.com/calculadora-roi" style="background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">CALCULADORA PERSONALIZADA DE ROI</a>
    </div>
    
    <p>Esses números são baseados em dados reais de empresas similares à {{COMPANY_NAME}}.</p>
    
    <p>Quer ver exatamente quanto SUA empresa pode economizar?</p>
    
    <p>Abraço,<br>
    <strong>Equipe Secretária IA</strong></p>
</body>
</html>`,
    textContent: `Oi {{LEAD_NAME}},

Fiz as contas para você baseado no perfil da {{COMPANY_NAME}}:

💰 R$ {{ROI_VALUE}}/mês em custos que você está perdendo SEM automação

📊 Breakdown dos custos:
• Salário recepcionista/atendente: R$ 2.500
• Leads perdidos (fora do horário): R$ 1.800  
• Reagendamentos manuais: R$ 900
• Qualificação inadequada: R$ 650
TOTAL MENSAL PERDIDO: R$ 5.850

Nossa solução: R$ 297/mês
SUA ECONOMIA: R$ 5.553/mês

Calculadora personalizada: https://secretariaai.com/calculadora-roi

Esses números são baseados em dados reais de empresas similares à {{COMPANY_NAME}}.

Quer ver exatamente quanto SUA empresa pode economizar?

Abraço,
Equipe Secretária IA`
  },

  // Email 5 - Depoimentos sociais (dia 10)
  {
    name: "Depoimentos Sociais",
    subject: "Veja o que nossos clientes falam (vídeos reais)",
    templateType: "testimonials",
    delayDays: 10,
    isActive: true,
    htmlContent: `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Depoimentos - Secretária IA</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #ff6b6b 0%, #4ecdc4 100%); padding: 20px; border-radius: 10px; margin-bottom: 30px; text-align: center;">
        <h1 style="color: white; margin: 0; font-size: 24px;">🎥 Clientes Reais, Resultados Reais</h1>
    </div>
    
    <p>Oi <strong>{{LEAD_NAME}}</strong>,</p>
    
    <p>Deixo os resultados falarem por si:</p>
    
    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0; color: #495057;">👨‍⚕️ Dr. Carlos - Clínica Odontológica (SP)</h3>
        <div style="background: #fff; padding: 15px; border-radius: 5px; margin: 10px 0;">
            <p style="margin: 0; font-style: italic;">"Em 60 dias nossa receita subiu 40%. A IA agenda, confirma e até faz o pré-atendimento. Pareço ter uma equipe de 5 pessoas trabalhando 24h."</p>
        </div>
        <div style="text-align: center;">
            <a href="https://secretariaai.com/depoimento-dr-carlos" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-size: 14px;">▶️ VER VÍDEO (2 min)</a>
        </div>
    </div>
    
    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0; color: #495057;">👩‍💼 Advocacia João & Associados (RJ)</h3>
        <div style="background: #fff; padding: 15px; border-radius: 5px; margin: 10px 0;">
            <p style="margin: 0; font-style: italic;">"Economizamos R$ 4.800/mês só em salários. A IA qualifica melhor que nossa antiga recepcionista e nunca 'esquece' de ligar para confirmar reuniões."</p>
        </div>
        <div style="text-align: center;">
            <a href="https://secretariaai.com/depoimento-advocacia" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-size: 14px;">▶️ VER VÍDEO (3 min)</a>
        </div>
    </div>
    
    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h3 style="margin-top: 0; color: #495057;">🏠 Imobiliária Premium (MG)</h3>
        <div style="background: #fff; padding: 15px; border-radius: 5px; margin: 10px 0;">
            <p style="margin: 0; font-style: italic;">"Agora atendemos leads até domingo de madrugada. Fechamos 3 vendas que normalmente perderíamos. ROI de 300% no primeiro mês."</p>
        </div>
        <div style="text-align: center;">
            <a href="https://secretariaai.com/depoimento-imobiliaria" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-size: 14px;">▶️ VER VÍDEO (2 min)</a>
        </div>
    </div>
    
    <p><strong>Todos</strong> com resultados reais e mensuráveis.</p>
    
    <div style="background: #d4edda; padding: 15px; border-radius: 8px; margin: 20px 0; text-align: center;">
        <p style="margin: 0; font-weight: bold;">💡 {{COMPANY_NAME}} pode ter resultados similares ou melhores!</p>
    </div>
    
    <div style="text-align: center; margin: 30px 0;">
        <a href="https://cal.com/secretaria-ia/demo" style="background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">AGENDAR MINHA DEMONSTRAÇÃO</a>
    </div>
    
    <p>Abraço,<br>
    <strong>Equipe Secretária IA</strong></p>
</body>
</html>`,
    textContent: `Oi {{LEAD_NAME}},

Deixo os resultados falarem por si:

👨‍⚕️ Dr. Carlos - Clínica Odontológica (SP)
"Em 60 dias nossa receita subiu 40%. A IA agenda, confirma e até faz o pré-atendimento. Pareço ter uma equipe de 5 pessoas trabalhando 24h."
Ver vídeo: https://secretariaai.com/depoimento-dr-carlos

👩‍💼 Advocacia João & Associados (RJ)  
"Economizamos R$ 4.800/mês só em salários. A IA qualifica melhor que nossa antiga recepcionista e nunca 'esquece' de ligar para confirmar reuniões."
Ver vídeo: https://secretariaai.com/depoimento-advocacia

🏠 Imobiliária Premium (MG)
"Agora atendemos leads até domingo de madrugada. Fechamos 3 vendas que normalmente perderíamos. ROI de 300% no primeiro mês."
Ver vídeo: https://secretariaai.com/depoimento-imobiliaria

Todos com resultados reais e mensuráveis.

💡 {{COMPANY_NAME}} pode ter resultados similares ou melhores!

Agendar demonstração: https://cal.com/secretaria-ia/demo

Abraço,
Equipe Secretária IA`
  },

  // Email 6 - Oferta especial (dia 14)
  {
    name: "Oferta Especial",
    subject: "⏰ 48h restantes: 30% OFF + setup gratuito (R$ 1.200)",
    templateType: "special_offer",
    delayDays: 14,
    isActive: true,
    htmlContent: `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oferta Especial - Secretária IA</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: #dc3545; padding: 20px; border-radius: 10px; margin-bottom: 30px; text-align: center;">
        <h1 style="color: white; margin: 0; font-size: 24px;">⏰ OFERTA EXPIRA EM 48 HORAS</h1>
    </div>
    
    <p>Oi <strong>{{LEAD_NAME}}</strong>,</p>
    
    <p>Esta é sua última chance de aproveitar nossa <strong>oferta de lançamento</strong>:</p>
    
    <div style="background: #fff3cd; border: 3px solid #ffc107; padding: 25px; border-radius: 10px; margin: 20px 0; text-align: center;">
        <h2 style="margin: 0 0 15px 0; color: #856404;">🎁 PACOTE COMPLETO:</h2>
        <ul style="text-align: left; max-width: 300px; margin: 0 auto;">
            <li><strong>30% de desconto</strong> nos primeiros 6 meses</li>
            <li><strong>Setup completo GRATUITO</strong> (valor R$ 1.200)</li>
            <li><strong>Treinamento personalizado</strong> da sua IA</li>
            <li><strong>Suporte VIP</strong> por 90 dias</li>
        </ul>
    </div>
    
    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <table style="width: 100%; border-collapse: collapse;">
            <tr style="background: #e9ecef;">
                <td style="padding: 15px; font-weight: bold;">Valor normal:</td>
                <td style="padding: 15px; text-align: right; text-decoration: line-through; color: #6c757d;">R$ 297/mês</td>
            </tr>
            <tr style="background: #d4edda;">
                <td style="padding: 15px; font-weight: bold;">Seu preço (6 meses):</td>
                <td style="padding: 15px; text-align: right; color: #28a745; font-size: 20px; font-weight: bold;">R$ 207/mês</td>
            </tr>
            <tr style="background: #d1ecf1;">
                <td style="padding: 15px; font-weight: bold;">Setup gratuito:</td>
                <td style="padding: 15px; text-align: right; color: #17a2b8; font-weight: bold;">R$ 0 (economiza R$ 1.200)</td>
            </tr>
        </table>
    </div>
    
    <div style="background: #dc3545; color: white; padding: 15px; border-radius: 8px; margin: 20px 0; text-align: center;">
        <p style="margin: 0; font-size: 18px; font-weight: bold;">Oferta válida até: SEXTA, 23:59h</p>
        <p style="margin: 5px 0 0 0; font-size: 14px;">Apenas para os primeiros 50 clientes</p>
    </div>
    
    <div style="text-align: center; margin: 30px 0;">
        <a href="https://secretariaai.com/oferta-especial" style="background: #28a745; color: white; padding: 20px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 18px; display: inline-block; box-shadow: 0 4px 8px rgba(0,0,0,0.2);">🚀 GARANTIR DESCONTO AGORA</a>
    </div>
    
    <p>{{LEAD_NAME}}, considerando que {{COMPANY_NAME}} pode economizar <strong>R$ {{ROI_VALUE}}/mês</strong>, essa é uma decisão que se paga sozinha.</p>
    
    <p><strong>Não perca essa oportunidade!</strong></p>
    
    <p>Abraço,<br>
    <strong>Equipe Secretária IA</strong></p>
    
    <div style="border-top: 1px solid #eee; margin-top: 30px; padding-top: 20px; text-align: center; font-size: 12px; color: #666;">
        <p>⚡ Vagas limitadas | 🔒 Pagamento 100% seguro | ✅ Garantia de 30 dias</p>
    </div>
</body>
</html>`,
    textContent: `Oi {{LEAD_NAME}},

Esta é sua última chance de aproveitar nossa oferta de lançamento:

🎁 PACOTE COMPLETO:
• 30% de desconto nos primeiros 6 meses
• Setup completo GRATUITO (valor R$ 1.200)  
• Treinamento personalizado da sua IA
• Suporte VIP por 90 dias

💰 PREÇOS:
Valor normal: R$ 297/mês
Seu preço (6 meses): R$ 207/mês
Setup gratuito: R$ 0 (economiza R$ 1.200)

⏰ Oferta válida até: SEXTA, 23:59h
Apenas para os primeiros 50 clientes

Garantir desconto: https://secretariaai.com/oferta-especial

{{LEAD_NAME}}, considerando que {{COMPANY_NAME}} pode economizar R$ {{ROI_VALUE}}/mês, essa é uma decisão que se paga sozinha.

Não perca essa oportunidade!

Abraço,
Equipe Secretária IA`
  },

  // Email 7 - Última chance (dia 21)
  {
    name: "Última Chance",
    subject: "Última tentativa (prometo não incomodar mais)",
    templateType: "last_chance",
    delayDays: 21,
    isActive: true,
    htmlContent: `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Última Chance - Secretária IA</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 30px; border-left: 4px solid #6c757d;">
        <h1 style="color: #495057; margin: 0; font-size: 24px;">✋ Última Mensagem</h1>
    </div>
    
    <p><strong>{{LEAD_NAME}}</strong>, esta é minha última mensagem.</p>
    
    <p>Entendo que talvez não seja o momento certo para a {{COMPANY_NAME}} automatizar o atendimento.</p>
    
    <p>Mas antes de "desistir" de você, quero fazer uma última oferta:</p>
    
    <div style="background: #e8f5e8; border: 2px solid #28a745; padding: 25px; border-radius: 10px; margin: 20px 0; text-align: center;">
        <h2 style="margin: 0 0 15px 0; color: #155724;">🎯 OFERTA FINAL</h2>
        <p style="margin: 0; font-size: 18px; font-weight: bold;">30 dias de teste GRATUITO<br>
        + Garantia total de reembolso<br>
        + Setup sem custo adicional</p>
    </div>
    
    <p><strong>Zero risco.</strong> Se em 30 dias você não economizar pelo menos R$ 1.000, devolvemos 100% do que você pagou.</p>
    
    <div style="text-align: center; margin: 30px 0;">
        <a href="https://secretariaai.com/teste-gratuito" style="background: #dc3545; color: white; padding: 20px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 18px; display: inline-block;">ACEITAR OFERTA FINAL</a>
    </div>
    
    <p>Caso não tenha interesse, pode ignorar este email.</p>
    
    <p>De qualquer forma, desejo muito sucesso para {{COMPANY_NAME}}! 🚀</p>
    
    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0; font-style: italic; color: #495057;">
        <p style="margin: 0;">"O maior risco é não correr risco algum... Em um mundo que está mudando rapidamente, a única estratégia que certamente falhará é não correr riscos."</p>
        <p style="margin: 5px 0 0 0; font-size: 14px; text-align: right;">- Mark Zuckerberg</p>
    </div>
    
    <p>Sucesso sempre!<br>
    <strong>Equipe Secretária IA</strong></p>
    
    <div style="border-top: 1px solid #eee; margin-top: 30px; padding-top: 20px; text-align: center; font-size: 12px; color: #666;">
        <p>Esta foi nossa última tentativa de contato automático.<br>
        Para falar conosco no futuro: <a href="mailto:contato@secretariaai.com">contato@secretariaai.com</a></p>
    </div>
</body>
</html>`,
    textContent: `{{LEAD_NAME}}, esta é minha última mensagem.

Entendo que talvez não seja o momento certo para a {{COMPANY_NAME}} automatizar o atendimento.

Mas antes de "desistir" de você, quero fazer uma última oferta:

🎯 OFERTA FINAL
• 30 dias de teste GRATUITO
• Garantia total de reembolso  
• Setup sem custo adicional

Zero risco. Se em 30 dias você não economizar pelo menos R$ 1.000, devolvemos 100% do que você pagou.

Aceitar oferta: https://secretariaai.com/teste-gratuito

Caso não tenha interesse, pode ignorar este email.

De qualquer forma, desejo muito sucesso para {{COMPANY_NAME}}! 🚀

"O maior risco é não correr risco algum... Em um mundo que está mudando rapidamente, a única estratégia que certamente falhará é não correr riscos."
- Mark Zuckerberg

Sucesso sempre!
Equipe Secretária IA

Esta foi nossa última tentativa de contato automático.
Para falar conosco no futuro: contato@secretariaai.com`
  }
];

// Personalization service
export class EmailPersonalizationService {
  static personalizeContent(content: string, lead: Lead): string {
    return content
      .replace(/{{LEAD_NAME}}/g, lead.name)
      .replace(/{{COMPANY_NAME}}/g, lead.company)
      .replace(/{{ROI_VALUE}}/g, this.calculateROI(lead).toString());
  }

  static personalizeSubject(subject: string, lead: Lead): string {
    return subject
      .replace(/{{LEAD_NAME}}/g, lead.name)
      .replace(/{{COMPANY_NAME}}/g, lead.company);
  }

  private static calculateROI(lead: Lead): number {
    // Calculate ROI based on lead data
    let baseROI = 2500; // Base value
    
    // Adjust based on company size
    switch (lead.companySize) {
      case '1-5':
        baseROI = 2100;
        break;
      case '6-20':
        baseROI = 3500;
        break;
      case '21-50':
        baseROI = 5200;
        break;
      case '50+':
        baseROI = 7800;
        break;
    }
    
    // Adjust based on revenue
    if (lead.revenue === '10k-50k') {
      baseROI *= 0.8;
    } else if (lead.revenue === '50k-200k') {
      baseROI *= 1.2;
    } else if (lead.revenue === '200k+') {
      baseROI *= 1.8;
    }
    
    return Math.round(baseROI);
  }
}

// Email sending simulation service
export class EmailSendingService {
  static async simulateSendEmail(emailId: string, lead: Lead, template: EmailTemplate): Promise<{ success: boolean; message: string }> {
    try {
      // Simulate email sending with random delay
      await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 500));
      
      // Simulate 95% success rate
      const success = Math.random() > 0.05;
      
      if (success) {
        console.log(`📧 EMAIL SIMULADO ENVIADO:
To: ${lead.email} (${lead.name})
Subject: ${EmailPersonalizationService.personalizeSubject(template.subject, lead)}
Template: ${template.name}
Scheduled ID: ${emailId}
Time: ${new Date().toISOString()}`);
        
        return {
          success: true,
          message: 'Email enviado com sucesso (simulação)'
        };
      } else {
        return {
          success: false,
          message: 'Falha no envio (simulação) - email inválido'
        };
      }
    } catch (error) {
      return {
        success: false,
        message: `Erro no envio: ${error instanceof Error ? error.message : 'Erro desconhecido'}`
      };
    }
  }
}

// Main email nurturing service
export class EmailNurturingService {
  // Initialize email templates in database
  static async initializeTemplates(): Promise<void> {
    try {
      for (const template of EMAIL_TEMPLATES) {
        const existing = await storage.getEmailTemplateByType(template.templateType);
        if (!existing) {
          await storage.createEmailTemplate(template);
          console.log(`✅ Template criado: ${template.name}`);
        }
      }
      console.log('🎯 Todos os templates de email foram inicializados');
    } catch (error) {
      console.error('❌ Erro ao inicializar templates:', error);
    }
  }

  // Start email campaign for a qualified lead
  static async startCampaignForLead(lead: Lead): Promise<void> {
    try {
      // Check if lead already has an active campaign
      const existingCampaign = await storage.getEmailCampaignByLead(lead.id);
      if (existingCampaign && existingCampaign.status === 'active') {
        console.log(`Campaign já existe para lead ${lead.name}`);
        return;
      }

      // Create email campaign
      const campaign = await storage.createEmailCampaign({
        leadId: lead.id,
        status: 'active',
        totalEmails: 7
      });

      console.log(`📧 Nova campanha criada para ${lead.name} (${lead.company})`);

      // Get all templates
      const templates = await storage.getEmailTemplates();
      
      // Schedule all emails
      for (const template of templates) {
        const scheduledDate = new Date();
        scheduledDate.setDate(scheduledDate.getDate() + template.delayDays);

        const personalizedSubject = EmailPersonalizationService.personalizeSubject(template.subject, lead);
        const personalizedContent = EmailPersonalizationService.personalizeContent(template.htmlContent, lead);

        await storage.createScheduledEmail({
          campaignId: campaign.id,
          leadId: lead.id,
          templateId: template.id,
          scheduledAt: scheduledDate,
          personalizedSubject,
          personalizedContent
        });

        console.log(`⏰ Email agendado: ${template.name} para ${scheduledDate.toLocaleDateString()}`);
      }

      console.log(`✅ Campanha completa agendada para ${lead.name}`);
    } catch (error) {
      console.error('❌ Erro ao criar campanha:', error);
    }
  }

  // Process emails that are ready to be sent
  static async processScheduledEmails(): Promise<void> {
    try {
      const emailsToSend = await storage.getEmailsToSend();
      
      console.log(`📬 Processando ${emailsToSend.length} emails para envio`);
      
      for (const scheduledEmail of emailsToSend) {
        // Get lead and template data
        const lead = await storage.getLead(scheduledEmail.leadId);
        const template = await storage.getEmailTemplate(scheduledEmail.templateId);
        
        if (!lead || !template) {
          console.error(`❌ Lead ou template não encontrado para email ${scheduledEmail.id}`);
          continue;
        }

        // Simulate sending email
        const result = await EmailSendingService.simulateSendEmail(scheduledEmail.id, lead, template);
        
        if (result.success) {
          // Update email status to sent
          await storage.updateScheduledEmailStatus(scheduledEmail.id, 'sent', new Date());
          
          // Update campaign metrics
          const campaign = await storage.getEmailCampaign(scheduledEmail.campaignId);
          if (campaign) {
            await storage.updateEmailCampaignMetrics(campaign.id, {
              emailsSent: campaign.emailsSent + 1
            });
          }
        } else {
          // Mark as failed
          await storage.updateScheduledEmailStatus(scheduledEmail.id, 'failed');
          console.error(`❌ Falha no envio: ${result.message}`);
        }
      }
    } catch (error) {
      console.error('❌ Erro ao processar emails:', error);
    }
  }

  // Simulate email tracking (opens and clicks)
  static async simulateEmailTracking(): Promise<void> {
    try {
      // Get sent emails from last 7 days
      const sentEmails = await storage.getEmailsToSend(); // We'll modify this query
      
      for (const email of sentEmails) {
        if (email.status === 'sent' && !email.openedAt) {
          // Simulate 35% open rate
          if (Math.random() < 0.35) {
            const openTime = new Date(email.sentAt!.getTime() + Math.random() * 24 * 60 * 60 * 1000);
            await storage.updateScheduledEmailStatus(email.id, 'opened', undefined, openTime);
            
            // Update campaign metrics
            const campaign = await storage.getEmailCampaign(email.campaignId);
            if (campaign) {
              await storage.updateEmailCampaignMetrics(campaign.id, {
                emailsOpened: campaign.emailsOpened + 1
              });
            }
            
            // Simulate 8% click rate (of opened emails)
            if (Math.random() < 0.08) {
              const clickTime = new Date(openTime.getTime() + Math.random() * 6 * 60 * 60 * 1000);
              await storage.updateScheduledEmailStatus(email.id, 'clicked', undefined, undefined, clickTime);
              
              if (campaign) {
                await storage.updateEmailCampaignMetrics(campaign.id, {
                  emailsClicked: campaign.emailsClicked + 1
                });
              }
            }
          }
        }
      }
    } catch (error) {
      console.error('❌ Erro ao simular tracking:', error);
    }
  }
}

// Background job to process emails (would run on cron in production)
export const startEmailProcessor = () => {
  // Initialize templates on startup
  EmailNurturingService.initializeTemplates();
  
  // Process emails every 5 minutes
  setInterval(async () => {
    await EmailNurturingService.processScheduledEmails();
  }, 5 * 60 * 1000);
  
  // Simulate tracking every 10 minutes
  setInterval(async () => {
    await EmailNurturingService.simulateEmailTracking();
  }, 10 * 60 * 1000);
  
  console.log('🚀 Email processor iniciado - processando a cada 5 minutos');
};